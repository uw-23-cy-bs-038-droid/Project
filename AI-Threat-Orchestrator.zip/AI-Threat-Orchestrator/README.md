# AI-Powered Threat Orchestrator
### All-In-One Security Brain
**Tagline:** AI-Assisted Threat Intelligence & Automated Security Investigation

A complete, runnable, single-file Flask application that correlates multiple
security intelligence signals with a local machine-learning model to produce an
explainable risk verdict for any indicator (URL, domain, IP, email, file hash,
or suspicious text). Built for university cybersecurity submission, portfolio
demonstration, and future SaaS commercialization.

> This is **not** a simple API aggregator. It performs indicator identification,
> multi-source orchestration, ML classification, weighted signal correlation
> with re-normalization for missing providers, and generates a transparent,
> explainable verdict plus a professional PDF report.

---

## 1. Project Introduction
Threat Orchestrator ingests a single indicator, automatically detects its type,
queries only the relevant analysis modules, runs a local RandomForest model,
correlates every available signal through a weighted Risk Engine, and outputs a
0-100 risk score with a CRITICAL/HIGH/MEDIUM/MODERATE/LOW verdict, an
explanation, security recommendations, and a downloadable PDF report.

## 2. Problem Statement
Security analysts juggle many disconnected tools (VirusTotal, PhishTank, HIBP,
WHOIS, DNS, SSL). Correlating them manually is slow and error-prone, and a
missing data source is often silently treated as "safe". This project unifies
those signals, applies ML, and correlates them transparently.

## 3. Objectives
- Automatic indicator identification and normalization.
- Orchestrated, fault-isolated multi-provider analysis.
- Local, explainable ML classification (no external LLM dependency).
- Weighted risk correlation that re-normalizes around unavailable signals.
- Professional SOC-style dashboard, history, and PDF reporting.
- SaaS scaffolding: auth, roles, billing, demo payments, audit logs.

## 4. Features
Dashboard - New Investigation - Automatic indicator detection - URL/Domain/IP/
Email/Hash analysis - DNS/WHOIS/SSL analysis - VirusTotal/PhishTank/HIBP
architecture - Local RandomForest ML + dataset generator + CSV loading + model
training + metrics + confusion matrix - Risk Engine with signal correlation and
re-normalization - Explainable AI verdict - Investigation history (search /
filter / sort / paginate) - PDF reports - Notifications - Audit logs - Admin
panel - Billing & subscription plans - Easypaisa/JazzCash demo payments -
Provider/API status - Demo mode - Error handling - Rate limiting - CSRF
protection - Secure sessions - SSRF protections.

## 5. Architecture
```
USER INDICATOR -> VALIDATION -> INDICATOR IDENTIFIER -> THREAT ORCHESTRATOR
  -> {VirusTotal, PhishTank, HIBP, DNS, WHOIS, SSL, URL Features, ML}
  -> SIGNAL CORRELATION -> RISK ENGINE -> FINAL VERDICT
  -> {Web Dashboard, Explanation, PDF Report}
```
The single `app.py` is organized with classes/functions so it can later be split
into `frontend/ backend/ ml/ integrations/ database/ reports/ payments/`.

## 6. Technology Stack
Python 3.11+, Flask, Flask-SQLAlchemy (SQLite), Flask-WTF (CSRF),
Flask-Limiter, Werkzeug, requests, dnspython, python-whois, scikit-learn,
pandas, numpy, joblib, reportlab, python-dotenv, Chart.js (CDN).

## 7. Installation
```bash
python --version          # 3.11+ expected
python -m venv venv
# Linux/macOS:
source venv/bin/activate
# Windows:
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Then open http://127.0.0.1:5000

## 8. Windows Setup
```bat
python --version
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

## 9. VS Code Setup
1. Open the project folder in VS Code.
2. Select the `venv` interpreter (Ctrl+Shift+P -> Python: Select Interpreter).
3. Copy `.env.example` to `.env` and edit as needed.
4. Run `python app.py` in the integrated terminal (or press F5).

## 10. Environment Configuration
Copy `.env.example` to `.env`. Everything is optional: with all values blank the
app runs entirely in DEMO MODE. Set `SECRET_KEY` for stable sessions and
`ADMIN_EMAIL`/`ADMIN_PASSWORD` to create an administrator.

## 11. API Setup
- **VirusTotal:** create a free account at virustotal.com, copy your API key into
  `VIRUSTOTAL_API_KEY`.
- **PhishTank:** register at phishtank.org for an application key (optional).
- **HIBP:** purchase a key at haveibeenpwned.com/API/Key, set `HIBP_API_KEY`.
When a key is missing the provider reports **Not Configured** and, in DEMO MODE,
returns clearly labelled simulated data. A missing provider is **never** treated
as "safe".

## 12. ML Methodology
A `RandomForestClassifier` (scikit-learn) is trained on a 15-dimension feature
vector extracted from each indicator (URL length, dots, hyphens, digits, HTTPS,
IP-as-host, suspicious keywords, subdomain count, depth, `@` presence, query
params, fragment, suspicious TLD, etc.). It classifies into
**Benign / Suspicious / Malicious**. The malicious probability it outputs feeds
the Risk Engine as the "Machine Learning" signal (30% base weight). XGBoost is
optionally supported; RandomForest is always the fallback.

## 13. Dataset
`generate_sample_dataset()` produces a clearly-labelled **DEMONSTRATION DATASET**
synthesised from URL characteristics (not real-world threat intelligence). You
can also train from a CSV with columns `url,label`:
```
url,label
https://example.com,0
http://example-login.com/verify,1
```

## 14. Database
SQLite via SQLAlchemy ORM. Models: User, Organization (multi-tenancy-ready),
Investigation, Indicator, ThreatResult, MLPrediction, Payment, Subscription,
Report, AuditLog, Notification. Foreign keys and indexes are used; no raw SQL.

## 15. Risk Engine
Weighted signals: Threat Intelligence 30%, ML 30%, Domain (WHOIS) 15%, DNS 10%,
URL features 10%, SSL 5%. If a provider is unavailable, its signal is excluded
and the remaining weights are **re-normalized** so the final score is always out
of 100. The report explicitly lists available vs. unavailable signals and shows
a full component breakdown. Verdicts: 0-20 LOW, 21-40 MODERATE, 41-60 MEDIUM,
61-80 HIGH, 81-100 CRITICAL.

## 16. Threat Orchestration
`ThreatOrchestrator` validates input, detects & normalizes the indicator,
selects only applicable providers per type, executes each module with isolated
error handling (one failure never aborts the investigation), extracts ML
features, predicts, correlates, explains, and persists everything.

## 17. Payment Architecture
`EasypaisaPaymentGateway` and `JazzCashPaymentGateway` share a clean abstraction
with three modes: DEMO, SANDBOX, PRODUCTION. Without merchant credentials the
gateway falls back to **DEMO PAYMENT MODE**, issuing a `DEMO-TRANSACTION-XXXX`
id and activating the chosen plan with a clear "No real money was charged"
label. Production integration requires provider merchant onboarding.

## 18. Demo Mode
`DEMO_MODE=true` labels the UI, allows clearly-marked simulated provider data,
and never presents simulated results as real threat intelligence.

## 19. Security Considerations
Input validation, ORM-only DB access, Werkzeug password hashing, CSRF
protection, secure session cookies, rate limiting, network timeouts, exception
handling, audit logging, environment-based secret management (no keys in the
frontend), and SSRF protection (blocks localhost / private / link-local /
reserved / cloud-metadata targets unless `ALLOW_PRIVATE_TARGETS=true`). No
offensive capabilities are implemented.

## 20. Testing
See the checklist below (section "Testing sequence").

## 21. Screenshots
_Add screenshots of the dashboard, investigation result, ML center, and PDF
report here for your submission._

## 22. Future Enhancements
PostgreSQL, Redis, Celery/RQ async orchestration, Docker, Nginx/HTTPS, cloud
deployment, multi-tenancy & teams, LLM-backed explanations via the existing
`AIAnalysisEngine` abstraction, API subscriptions.

## 23. Limitations
The bundled ML model is trained on a synthetic demonstration dataset and is for
educational use. Threat intelligence results may contain false positives or
negatives. A "safe" result is not a guarantee.

## 24. Ethical / Legal Disclaimer
This platform is designed for defensive cybersecurity analysis and authorized
security investigations only. Users are responsible for ensuring that
investigations are authorized and comply with applicable laws and policies.

---

## Admin Setup
Set in `.env`:
```
ADMIN_EMAIL=admin@yourschool.edu
ADMIN_PASSWORD=a-strong-password
```
Restart the app; the admin account is created automatically (only when both are
present). Log in and the **Admin Panel** appears in the sidebar.

## Testing sequence
1. **Valid URL** -> investigation created, analysis completes, risk score shown,
   PDF downloadable.
2. **Invalid/empty input** -> validation error, no crash.
3. **Missing API key** -> provider shows "Not Configured"/"Provider unavailable"
   and the app keeps working.
4. **ML** -> Machine Learning page; click "Train / Retrain Model"; metrics +
   confusion matrix update.
5. **PDF** -> "Download PDF Report" on any investigation.
6. **Auth** -> register, login, logout, protected routes redirect.
7. **Demo payment** -> Billing page; pick a plan + Easypaisa/JazzCash; a
   DEMO transaction id is created and the plan activates.
8. **Admin** -> configure admin in `.env`; view users, stats, API status, and
   audit logs.

## Run
```bash
python app.py
```
Local URL: **http://127.0.0.1:5000**
