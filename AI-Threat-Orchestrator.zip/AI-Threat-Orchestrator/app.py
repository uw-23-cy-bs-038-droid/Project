# =============================================================================
# AI-Powered Threat Orchestrator  -  All-In-One Security Brain
# Tagline: AI-Assisted Threat Intelligence & Automated Security Investigation
#
# Single-file Flask application (app.py).
# Run:  python app.py   ->  http://127.0.0.1:5000
#
# This file intentionally bundles backend, DB models, service classes, the ML
# pipeline, the risk engine, PDF reporting, payment gateway abstractions, the
# REST API and the embedded (dark SOC-themed) frontend so it can be launched
# with a single command. It is architected with classes/functions so it can be
# split later into frontend/ backend/ ml/ integrations/ database/ reports/
# payments/ packages.
# =============================================================================

import os
import re
import ssl
import json
import math
import socket
import random
import logging
import ipaddress
import datetime as dt
from functools import wraps
from urllib.parse import urlparse

# ------------------------- Third-party (required) ---------------------------
from flask import (
    Flask, request, session, redirect, url_for, jsonify,
    render_template_string, send_file, abort, g, flash
)
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy

# ------------------------- Third-party (optional) ---------------------------
# Everything below is imported defensively. If a package is missing the app
# still starts; the relevant feature simply reports itself as unavailable.
try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:  # pragma: no cover
    pass

try:
    from flask_wtf import CSRFProtect
    _HAS_CSRF = True
except Exception:
    CSRFProtect = None
    _HAS_CSRF = False

try:
    from flask_limiter import Limiter
    from flask_limiter.util import get_remote_address
    _HAS_LIMITER = True
except Exception:
    Limiter = None
    get_remote_address = None
    _HAS_LIMITER = False

try:
    import requests
    _HAS_REQUESTS = True
except Exception:
    requests = None
    _HAS_REQUESTS = False

try:
    import dns.resolver  # dnspython
    _HAS_DNS = True
except Exception:
    _HAS_DNS = False

try:
    import whois as whois_lib  # python-whois
    _HAS_WHOIS = True
except Exception:
    _HAS_WHOIS = False

try:
    import numpy as np
    import pandas as pd
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import (
        accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
    )
    import joblib
    _HAS_ML = True
except Exception:
    _HAS_ML = False

try:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.units import mm
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    )
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    _HAS_PDF = True
except Exception:
    _HAS_PDF = False

import io

# =============================================================================
# Configuration
# =============================================================================
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
MODEL_DIR = os.environ.get("MODEL_DIR", os.path.join(BASE_DIR, "models"))
MODEL_PATH = os.path.join(MODEL_DIR, "threat_model.joblib")
try:
    os.makedirs(MODEL_DIR, exist_ok=True)
except Exception:
    MODEL_DIR = BASE_DIR
    MODEL_PATH = os.path.join(BASE_DIR, "threat_model.joblib")


def _bool_env(name, default=False):
    val = os.environ.get(name)
    if val is None:
        return default
    return str(val).strip().lower() in ("1", "true", "yes", "on")


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY") or "dev-" + os.urandom(16).hex()
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", "sqlite:///threat_orchestrator.db"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Feature flags
    DEMO_MODE = _bool_env("DEMO_MODE", True)
    PAYMENT_DEMO_MODE = _bool_env("PAYMENT_DEMO_MODE", True)

    # Provider keys (never sent to the frontend)
    VIRUSTOTAL_API_KEY = os.environ.get("VIRUSTOTAL_API_KEY", "").strip()
    PHISHTANK_API_KEY = os.environ.get("PHISHTANK_API_KEY", "").strip()
    HIBP_API_KEY = os.environ.get("HIBP_API_KEY", "").strip()

    # Payment config
    EASYPAISA_MERCHANT_ID = os.environ.get("EASYPAISA_MERCHANT_ID", "").strip()
    EASYPAISA_API_KEY = os.environ.get("EASYPAISA_API_KEY", "").strip()
    JAZZCASH_MERCHANT_ID = os.environ.get("JAZZCASH_MERCHANT_ID", "").strip()
    JAZZCASH_PASSWORD = os.environ.get("JAZZCASH_PASSWORD", "").strip()
    JAZZCASH_INTEGRITY_SALT = os.environ.get("JAZZCASH_INTEGRITY_SALT", "").strip()

    # Admin bootstrap
    ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL", "").strip()
    ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "").strip()

    # Networking safety
    HTTP_TIMEOUT = float(os.environ.get("HTTP_TIMEOUT", "8"))
    ALLOW_PRIVATE_TARGETS = _bool_env("ALLOW_PRIVATE_TARGETS", False)

    # Session hardening
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = _bool_env("SESSION_COOKIE_SECURE", False)


# Plan definitions (PKR)
PLANS = {
    "free": {"name": "Free", "price": 0, "scans": 5,
             "features": ["5 scans/month", "Basic reports", "Limited intelligence"]},
    "pro": {"name": "Pro", "price": 1500, "scans": 100,
            "features": ["100 scans/month", "Full threat intelligence",
                         "ML analysis", "PDF reports", "Priority processing"]},
    "business": {"name": "Business", "price": 6000, "scans": 1000,
                 "features": ["High-limit scans", "Advanced reports",
                              "Team accounts", "API access", "Priority support"]},
}

# Provider availability states
AVAILABLE = "AVAILABLE"
UNAVAILABLE = "UNAVAILABLE"
NOT_CONFIGURED = "NOT_CONFIGURED"
ERROR = "ERROR"
NOT_APPLICABLE = "NOT_APPLICABLE"

# =============================================================================
# Logging
# =============================================================================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
log = logging.getLogger("threat-orchestrator")

# =============================================================================
# Flask app + extensions
# =============================================================================
app = Flask(__name__)
app.config.from_object(Config)

db = SQLAlchemy(app)

csrf = None
if _HAS_CSRF:
    csrf = CSRFProtect(app)

limiter = None
if _HAS_LIMITER:
    try:
        limiter = Limiter(
            get_remote_address,
            app=app,
            default_limits=["600 per hour"],
            storage_uri="memory://",
        )
    except Exception as exc:  # pragma: no cover
        log.warning("Rate limiter init failed: %s", exc)
        limiter = None


def rate_limit(rule):
    """Decorator that applies a Flask-Limiter rule if the extension exists."""
    def decorator(fn):
        if limiter is not None:
            return limiter.limit(rule)(fn)
        return fn
    return decorator


# =============================================================================
# Database models
# =============================================================================
class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(190), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), default="user", nullable=False)  # user | admin
    plan = db.Column(db.String(20), default="free", nullable=False)
    scans_used = db.Column(db.Integer, default=0)
    usage_period = db.Column(db.String(7), default="")  # YYYY-MM
    created_at = db.Column(db.DateTime, default=dt.datetime.utcnow)

    # Multi-tenancy ready (kept nullable / optional for the university version)
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=True)

    investigations = db.relationship("Investigation", backref="user", lazy=True)
    payments = db.relationship("Payment", backref="user", lazy=True)
    notifications = db.relationship("Notification", backref="user", lazy=True)

    def set_password(self, raw):
        self.password_hash = generate_password_hash(raw)

    def check_password(self, raw):
        return check_password_hash(self.password_hash, raw)

    def plan_limit(self):
        return PLANS.get(self.plan, PLANS["free"])["scans"]

    def ensure_period(self):
        period = dt.datetime.utcnow().strftime("%Y-%m")
        if self.usage_period != period:
            self.usage_period = period
            self.scans_used = 0

    def remaining_scans(self):
        self.ensure_period()
        return max(0, self.plan_limit() - self.scans_used)


class Organization(db.Model):
    """Optional tenant container. Present so relationships exist for the
    future multi-tenant / team edition without adding complexity now."""
    __tablename__ = "organizations"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(160), nullable=False)
    created_at = db.Column(db.DateTime, default=dt.datetime.utcnow)
    users = db.relationship("User", backref="organization", lazy=True)


class Investigation(db.Model):
    __tablename__ = "investigations"
    id = db.Column(db.Integer, primary_key=True)
    public_id = db.Column(db.String(24), unique=True, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    indicator_value = db.Column(db.String(600), nullable=False)
    indicator_type = db.Column(db.String(20), nullable=False)
    risk_score = db.Column(db.Integer, default=0)
    verdict = db.Column(db.String(20), default="LOW")
    confidence = db.Column(db.Integer, default=0)
    mode = db.Column(db.String(10), default="DEMO")   # LIVE | DEMO
    result_json = db.Column(db.Text, default="{}")
    created_at = db.Column(db.DateTime, default=dt.datetime.utcnow, index=True)

    indicators = db.relationship("Indicator", backref="investigation", lazy=True)
    threat_results = db.relationship("ThreatResult", backref="investigation", lazy=True)
    ml_predictions = db.relationship("MLPrediction", backref="investigation", lazy=True)
    reports = db.relationship("Report", backref="investigation", lazy=True)

    def result(self):
        try:
            return json.loads(self.result_json or "{}")
        except Exception:
            return {}


class Indicator(db.Model):
    __tablename__ = "indicators"
    id = db.Column(db.Integer, primary_key=True)
    investigation_id = db.Column(db.Integer, db.ForeignKey("investigations.id"))
    value = db.Column(db.String(600))
    itype = db.Column(db.String(20))
    normalized = db.Column(db.String(600))


class ThreatResult(db.Model):
    __tablename__ = "threat_results"
    id = db.Column(db.Integer, primary_key=True)
    investigation_id = db.Column(db.Integer, db.ForeignKey("investigations.id"))
    provider = db.Column(db.String(40))
    status = db.Column(db.String(20))
    verdict = db.Column(db.String(20))
    score = db.Column(db.Float, default=0.0)
    details_json = db.Column(db.Text, default="{}")


class MLPrediction(db.Model):
    __tablename__ = "ml_predictions"
    id = db.Column(db.Integer, primary_key=True)
    investigation_id = db.Column(db.Integer, db.ForeignKey("investigations.id"))
    prediction = db.Column(db.String(20))
    probability = db.Column(db.Float, default=0.0)
    confidence = db.Column(db.Float, default=0.0)
    features_json = db.Column(db.Text, default="{}")


class Payment(db.Model):
    __tablename__ = "payments"
    id = db.Column(db.Integer, primary_key=True)
    transaction_id = db.Column(db.String(60), unique=True, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    plan = db.Column(db.String(20))
    method = db.Column(db.String(20))       # easypaisa | jazzcash
    amount = db.Column(db.Float, default=0.0)
    currency = db.Column(db.String(6), default="PKR")
    status = db.Column(db.String(20))       # success | failure | cancelled | pending
    is_demo = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=dt.datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=dt.datetime.utcnow, onupdate=dt.datetime.utcnow)


class Subscription(db.Model):
    __tablename__ = "subscriptions"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    plan = db.Column(db.String(20))
    start_date = db.Column(db.DateTime, default=dt.datetime.utcnow)
    expiry_date = db.Column(db.DateTime)
    active = db.Column(db.Boolean, default=True)


class Report(db.Model):
    __tablename__ = "reports"
    id = db.Column(db.Integer, primary_key=True)
    investigation_id = db.Column(db.Integer, db.ForeignKey("investigations.id"))
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    created_at = db.Column(db.DateTime, default=dt.datetime.utcnow)


class AuditLog(db.Model):
    __tablename__ = "audit_logs"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    action = db.Column(db.String(80))
    indicator = db.Column(db.String(600), nullable=True)
    result = db.Column(db.String(200), nullable=True)
    ip_address = db.Column(db.String(60), nullable=True)
    created_at = db.Column(db.DateTime, default=dt.datetime.utcnow, index=True)


class Notification(db.Model):
    __tablename__ = "notifications"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    title = db.Column(db.String(160))
    body = db.Column(db.String(400))
    level = db.Column(db.String(20), default="info")  # info | success | warning | critical
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=dt.datetime.utcnow)


# ------------------------- Small persistence helpers ------------------------
def audit(action, indicator=None, result=None, user_id=None):
    try:
        entry = AuditLog(
            user_id=user_id if user_id is not None else session.get("uid"),
            action=action,
            indicator=(indicator or "")[:600] if indicator else None,
            result=(result or "")[:200] if result else None,
            ip_address=request.remote_addr if request else None,
        )
        db.session.add(entry)
        db.session.commit()
    except Exception as exc:  # never let auditing break the request
        log.warning("audit failed: %s", exc)
        db.session.rollback()


def notify(user_id, title, body, level="info"):
    try:
        db.session.add(Notification(user_id=user_id, title=title, body=body, level=level))
        db.session.commit()
    except Exception:
        db.session.rollback()


# =============================================================================
# Indicator identification, validation & SSRF protection
# =============================================================================
SUSPICIOUS_KEYWORDS = [
    "login", "verify", "verification", "account", "secure", "update",
    "password", "bank", "signin", "confirm", "wallet", "payment",
    "webscr", "ebayisapi", "unlock", "billing", "invoice",
]
SUSPICIOUS_TLDS = {
    "zip", "review", "country", "kim", "cricket", "science", "work",
    "party", "gq", "link", "top", "click", "xyz", "tk", "ml", "ga", "cf",
}

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
MD5_RE = re.compile(r"^[a-fA-F0-9]{32}$")
SHA1_RE = re.compile(r"^[a-fA-F0-9]{40}$")
SHA256_RE = re.compile(r"^[a-fA-F0-9]{64}$")
DOMAIN_RE = re.compile(
    r"^(?=.{1,253}$)(?!-)[A-Za-z0-9-]{1,63}(?<!-)"
    r"(?:\.(?!-)[A-Za-z0-9-]{1,63}(?<!-))+$"
)

MAX_INPUT_LEN = 2048


def detect_indicator_type(value):
    """Automatically classify a raw indicator string."""
    if not value:
        return "UNKNOWN"
    v = value.strip()

    # Hashes
    if MD5_RE.match(v):
        return "HASH"
    if SHA1_RE.match(v):
        return "HASH"
    if SHA256_RE.match(v):
        return "HASH"

    # Email
    if EMAIL_RE.match(v):
        return "EMAIL"

    # IP (v4 / v6)
    try:
        ipaddress.ip_address(v)
        return "IP"
    except ValueError:
        pass

    # URL (has scheme, or path/query with a dot)
    if re.match(r"^[a-zA-Z][a-zA-Z0-9+.\-]*://", v):
        return "URL"
    if ("/" in v or "?" in v) and "." in v.split("/")[0]:
        return "URL"

    # Domain
    if DOMAIN_RE.match(v):
        return "DOMAIN"

    # Fallback: free-form suspicious text
    return "TEXT"


def hash_kind(value):
    if MD5_RE.match(value):
        return "MD5"
    if SHA1_RE.match(value):
        return "SHA1"
    if SHA256_RE.match(value):
        return "SHA256"
    return "UNKNOWN"


def normalize_indicator(value, itype):
    v = value.strip()
    if itype == "EMAIL":
        return v.lower()
    if itype in ("DOMAIN",):
        return v.lower().rstrip(".")
    if itype == "URL":
        if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.\-]*://", v):
            v = "http://" + v
        return v
    if itype == "HASH":
        return v.lower()
    return v


def extract_hostname(value, itype):
    """Return the hostname/domain relevant to an indicator, or None."""
    if itype == "DOMAIN":
        return value.lower().rstrip(".")
    if itype == "URL":
        try:
            host = urlparse(value if "://" in value else "http://" + value).hostname
            return host.lower() if host else None
        except Exception:
            return None
    if itype == "IP":
        return value
    return None


def validate_indicator(value):
    """Return (ok, message). Enforces length + non-empty."""
    if value is None:
        return False, "Empty input"
    v = value.strip()
    if not v:
        return False, "Empty input"
    if len(v) > MAX_INPUT_LEN:
        return False, "Input too long"
    return True, "ok"


def is_private_target(hostname):
    """SSRF guard: resolve a hostname and decide whether it points at a
    private / loopback / link-local / reserved address. Returns True if the
    target must be blocked (unless ALLOW_PRIVATE_TARGETS is set)."""
    if not hostname:
        return False
    if app.config["ALLOW_PRIVATE_TARGETS"]:
        return False

    blocked_names = {"localhost", "metadata.google.internal"}
    if hostname.lower() in blocked_names:
        return True

    candidates = []
    # Direct literal IP?
    try:
        candidates.append(ipaddress.ip_address(hostname))
    except ValueError:
        # Resolve DNS to all addresses and test each
        try:
            infos = socket.getaddrinfo(hostname, None)
            for info in infos:
                addr = info[4][0]
                try:
                    candidates.append(ipaddress.ip_address(addr))
                except ValueError:
                    continue
        except Exception:
            # If we cannot resolve, do not treat as private; providers will
            # simply fail gracefully later.
            return False

    for ip in candidates:
        if (ip.is_private or ip.is_loopback or ip.is_link_local or
                ip.is_reserved or ip.is_multicast or ip.is_unspecified):
            return True
        # Cloud metadata endpoint
        if str(ip) == "169.254.169.254":
            return True
    return False


# =============================================================================
# URL / indicator feature extraction (for the ML model)
# =============================================================================
FEATURE_NAMES = [
    "url_length", "domain_length", "num_dots", "num_hyphens", "num_digits",
    "num_special", "https", "has_ip", "suspicious_keywords", "subdomain_count",
    "url_depth", "has_at", "num_query_params", "has_fragment", "suspicious_tld",
]


def extract_features(value, itype):
    """Compute a fixed-length numeric feature vector (dict) for an indicator.
    Works for URL/DOMAIN/IP; other types get a degraded but valid vector."""
    v = value.strip()
    work = v if "://" in v else "http://" + v
    try:
        parsed = urlparse(work)
    except Exception:
        parsed = None

    host = (parsed.hostname if parsed else None) or ""
    path = (parsed.path if parsed else "") or ""
    query = (parsed.query if parsed else "") or ""
    fragment = (parsed.fragment if parsed else "") or ""

    special_chars = re.findall(r"[^A-Za-z0-9]", v)
    has_ip = 0
    try:
        if host:
            ipaddress.ip_address(host)
            has_ip = 1
    except ValueError:
        has_ip = 0

    labels = host.split(".") if host else []
    subdomain_count = max(0, len(labels) - 2) if len(labels) >= 2 else 0
    tld = labels[-1].lower() if len(labels) >= 2 else ""

    kw_hits = sum(1 for k in SUSPICIOUS_KEYWORDS if k in v.lower())

    feats = {
        "url_length": len(v),
        "domain_length": len(host),
        "num_dots": v.count("."),
        "num_hyphens": v.count("-"),
        "num_digits": sum(c.isdigit() for c in v),
        "num_special": len(special_chars),
        "https": 1 if work.lower().startswith("https://") else 0,
        "has_ip": has_ip,
        "suspicious_keywords": kw_hits,
        "subdomain_count": subdomain_count,
        "url_depth": len([p for p in path.split("/") if p]),
        "has_at": 1 if "@" in v else 0,
        "num_query_params": len([q for q in query.split("&") if q]) if query else 0,
        "has_fragment": 1 if fragment else 0,
        "suspicious_tld": 1 if tld in SUSPICIOUS_TLDS else 0,
    }
    return feats


def features_to_vector(feats):
    return [float(feats.get(name, 0)) for name in FEATURE_NAMES]


# =============================================================================
# Machine Learning core  (RandomForest, 3-class: Benign/Suspicious/Malicious)
# =============================================================================
CLASS_NAMES = ["Benign", "Suspicious", "Malicious"]


def generate_sample_dataset(n=1200, seed=42):
    """Generate a clearly-labelled DEMONSTRATION DATASET of synthetic URLs.

    NOTE: This is a *demonstration* dataset generated from URL characteristics.
    It is NOT real-world threat intelligence and must never be presented as
    such. It exists so the ML pipeline is trainable out-of-the-box.
    """
    rng = random.Random(seed)
    good_tlds = ["com", "org", "net", "edu", "gov", "io"]
    bad_tlds = list(SUSPICIOUS_TLDS)
    good_words = ["home", "shop", "news", "blog", "cloud", "docs", "mail", "app"]
    bad_words = SUSPICIOUS_KEYWORDS

    rows = []
    for _ in range(n):
        label = rng.choices([0, 1, 2], weights=[0.45, 0.25, 0.30])[0]
        if label == 0:  # Benign
            host = "{}.{}".format(rng.choice(good_words), rng.choice(good_tlds))
            scheme = "https"
            path = rng.choice(["", "/", "/about", "/home", "/products"])
            url = "{}://{}{}".format(scheme, host, path)
        elif label == 1:  # Suspicious
            sub = rng.choice(good_words)
            host = "{}-{}.{}".format(sub, rng.choice(bad_words), rng.choice(good_tlds))
            scheme = rng.choice(["http", "https"])
            path = "/" + rng.choice(bad_words)
            url = "{}://{}{}".format(scheme, host, path)
        else:  # Malicious
            use_ip = rng.random() < 0.4
            if use_ip:
                host = "{}.{}.{}.{}".format(rng.randint(1, 254), rng.randint(0, 254),
                                            rng.randint(0, 254), rng.randint(1, 254))
            else:
                host = "{}-{}-{}.{}".format(rng.choice(bad_words),
                                            rng.choice(bad_words),
                                            rng.randint(1, 9999),
                                            rng.choice(bad_tlds))
            scheme = "http"
            path = "/" + "/".join(rng.sample(bad_words, k=rng.randint(1, 3)))
            at = "@evil" if rng.random() < 0.3 else ""
            url = "{}://{}{}{}".format(scheme, host, at, path)
        rows.append({"url": url, "label": label})
    return rows


class MLModel:
    """Local RandomForest classifier with graceful degradation."""

    def __init__(self, path=MODEL_PATH):
        self.path = path
        self.model = None
        self.metrics = {}
        self.meta = {}

    # ---- persistence ----
    def load(self):
        if not _HAS_ML:
            return False
        if os.path.exists(self.path):
            try:
                blob = joblib.load(self.path)
                self.model = blob.get("model")
                self.metrics = blob.get("metrics", {})
                self.meta = blob.get("meta", {})
                return True
            except Exception as exc:
                log.warning("model load failed: %s", exc)
        return False

    def save(self):
        if not _HAS_ML or self.model is None:
            return
        try:
            joblib.dump(
                {"model": self.model, "metrics": self.metrics, "meta": self.meta},
                self.path,
            )
        except Exception as exc:
            log.warning("model save failed: %s", exc)

    # ---- training ----
    def train_from_rows(self, rows, source="DEMONSTRATION DATASET"):
        if not _HAS_ML:
            raise RuntimeError("scikit-learn not available")
        X, y = [], []
        for r in rows:
            try:
                label = int(r["label"])
            except Exception:
                continue
            feats = extract_features(str(r["url"]), "URL")
            X.append(features_to_vector(feats))
            y.append(label)
        if len(set(y)) < 2:
            raise RuntimeError("Dataset needs at least 2 classes")

        X = np.array(X, dtype=float)
        y = np.array(y, dtype=int)
        X_tr, X_te, y_tr, y_te = train_test_split(
            X, y, test_size=0.25, random_state=42,
            stratify=y if len(set(y)) > 1 else None,
        )
        clf = RandomForestClassifier(
            n_estimators=180, max_depth=14, random_state=42, n_jobs=-1
        )
        clf.fit(X_tr, y_tr)
        preds = clf.predict(X_te)

        avg = "macro"
        self.model = clf
        self.metrics = {
            "accuracy": round(float(accuracy_score(y_te, preds)), 4),
            "precision": round(float(precision_score(y_te, preds, average=avg, zero_division=0)), 4),
            "recall": round(float(recall_score(y_te, preds, average=avg, zero_division=0)), 4),
            "f1": round(float(f1_score(y_te, preds, average=avg, zero_division=0)), 4),
            "confusion_matrix": confusion_matrix(y_te, preds).tolist(),
            "classes": [CLASS_NAMES[i] if i < len(CLASS_NAMES) else str(i)
                        for i in sorted(set(y.tolist()))],
        }
        self.meta = {
            "trained_at": dt.datetime.utcnow().isoformat() + "Z",
            "samples": int(len(X)),
            "model_type": "RandomForestClassifier",
            "source": source,
            "feature_names": FEATURE_NAMES,
        }
        self.save()
        return self.metrics

    def load_csv(self, path):
        """Load a user CSV with columns: url,label"""
        if not _HAS_ML:
            raise RuntimeError("pandas/scikit-learn not available")
        df = pd.read_csv(path)
        cols = {c.lower(): c for c in df.columns}
        if "url" not in cols or "label" not in cols:
            raise RuntimeError("CSV must contain 'url' and 'label' columns")
        rows = [{"url": r[cols["url"]], "label": r[cols["label"]]}
                for _, r in df.iterrows()]
        return self.train_from_rows(rows, source="USER CSV DATASET")

    # ---- prediction ----
    def predict(self, value, itype):
        """Return dict: prediction, probability(malicious), confidence, features.
        Falls back cleanly if the model is unavailable."""
        feats = extract_features(value, itype)
        if not _HAS_ML or self.model is None:
            return {
                "available": False,
                "prediction": "ML model unavailable",
                "probability": None,
                "confidence": None,
                "features": feats,
            }
        vec = np.array([features_to_vector(feats)], dtype=float)
        try:
            proba = self.model.predict_proba(vec)[0]
            classes = list(self.model.classes_)
            # Map class indices -> names
            idx_best = int(np.argmax(proba))
            best_class = classes[idx_best]
            pred_name = CLASS_NAMES[best_class] if best_class < len(CLASS_NAMES) else str(best_class)
            # Malicious probability = probability mass on class 2 (+ half of suspicious)
            mal_prob = 0.0
            for cls, p in zip(classes, proba):
                if cls == 2:
                    mal_prob += p
                elif cls == 1:
                    mal_prob += 0.5 * p
            confidence = float(np.max(proba))
            return {
                "available": True,
                "prediction": pred_name,
                "probability": round(float(mal_prob) * 100, 1),
                "confidence": round(confidence * 100, 1),
                "features": feats,
            }
        except Exception as exc:
            log.warning("ML predict failed: %s", exc)
            return {
                "available": False,
                "prediction": "ML model unavailable",
                "probability": None,
                "confidence": None,
                "features": feats,
            }


ML = MLModel()


# =============================================================================
# Provider result helper  (normalized structure everywhere)
# =============================================================================
def provider_result(provider, status, verdict="NORMAL", score=0.0, details=None, error=None):
    return {
        "provider": provider,
        "status": status,
        "verdict": verdict,
        "score": float(score),
        "details": details or {},
        "error": error,
    }


def _http_get(url, headers=None, params=None):
    """Guarded HTTP GET with timeout + SSRF host check for the *target*
    (provider endpoints are trusted; user-derived hosts are checked upstream)."""
    if not _HAS_REQUESTS:
        raise RuntimeError("requests library unavailable")
    return requests.get(
        url, headers=headers or {}, params=params or {},
        timeout=app.config["HTTP_TIMEOUT"], allow_redirects=False,
    )


# =============================================================================
# VirusTotal
# =============================================================================
class VirusTotalService:
    BASE = "https://www.virustotal.com/api/v3"

    def __init__(self, api_key):
        self.api_key = api_key

    def _headers(self):
        return {"x-apikey": self.api_key}

    def _configured(self):
        return bool(self.api_key)

    def _demo(self, indicator):
        # Deterministic pseudo-result derived from the indicator (labelled DEMO)
        seed = sum(ord(c) for c in indicator)
        malicious = seed % 7
        detections = malicious
        verdict = "MALICIOUS" if detections >= 3 else ("SUSPICIOUS" if detections == 2 else "SAFE")
        score = min(100, detections * 18)
        return provider_result(
            "VirusTotal", AVAILABLE, verdict, score,
            {"detections": detections, "engines": 70, "simulated": True},
        )

    def _query(self, path):
        if app.config["DEMO_MODE"] and not self._configured():
            return None  # caller will produce a labelled demo result
        if not self._configured():
            return provider_result("VirusTotal", NOT_CONFIGURED,
                                   error="VirusTotal: API key not configured")
        if not _HAS_REQUESTS:
            return provider_result("VirusTotal", UNAVAILABLE, error="requests unavailable")
        try:
            resp = _http_get("{}/{}".format(self.BASE, path), headers=self._headers())
            if resp.status_code == 401:
                return provider_result("VirusTotal", NOT_CONFIGURED, error="Invalid API key")
            if resp.status_code == 404:
                return provider_result("VirusTotal", AVAILABLE, "SAFE", 0,
                                       {"detections": 0, "note": "not found"})
            if resp.status_code != 200:
                return provider_result("VirusTotal", ERROR, error="HTTP %s" % resp.status_code)
            data = resp.json()
            stats = (data.get("data", {}).get("attributes", {})
                     .get("last_analysis_stats", {}))
            malicious = int(stats.get("malicious", 0))
            suspicious = int(stats.get("suspicious", 0))
            total = sum(int(v) for v in stats.values()) or 1
            score = min(100, (malicious * 100.0 / total) + suspicious * 2)
            verdict = ("MALICIOUS" if malicious >= 3 else
                       "SUSPICIOUS" if (malicious + suspicious) > 0 else "SAFE")
            return provider_result("VirusTotal", AVAILABLE, verdict, score,
                                   {"detections": malicious, "suspicious": suspicious,
                                    "engines": total})
        except Exception as exc:
            return provider_result("VirusTotal", ERROR, error=str(exc))

    def analyze_url(self, url):
        import base64
        if app.config["DEMO_MODE"] and not self._configured():
            return self._demo(url)
        url_id = base64.urlsafe_b64encode(url.encode()).decode().strip("=")
        return self._query("urls/{}".format(url_id))

    def analyze_domain(self, domain):
        if app.config["DEMO_MODE"] and not self._configured():
            return self._demo(domain)
        return self._query("domains/{}".format(domain))

    def analyze_ip(self, ip):
        if app.config["DEMO_MODE"] and not self._configured():
            return self._demo(ip)
        return self._query("ip_addresses/{}".format(ip))

    def analyze_hash(self, h):
        if app.config["DEMO_MODE"] and not self._configured():
            return self._demo(h)
        return self._query("files/{}".format(h))


# =============================================================================
# PhishTank
# =============================================================================
class PhishTankService:
    ENDPOINT = "https://checkurl.phishtank.com/checkurl/"

    def __init__(self, api_key):
        self.api_key = api_key

    def analyze_url(self, url):
        if app.config["DEMO_MODE"] and not self.api_key:
            seed = sum(ord(c) for c in url)
            phish = (seed % 5 == 0)
            return provider_result(
                "PhishTank", AVAILABLE,
                "MALICIOUS" if phish else "SAFE",
                80 if phish else 0,
                {"in_database": phish, "simulated": True},
            )
        if not _HAS_REQUESTS:
            return provider_result("PhishTank", UNAVAILABLE,
                                   error="PhishTank: Provider unavailable")
        try:
            data = {"url": url, "format": "json"}
            if self.api_key:
                data["app_key"] = self.api_key
            resp = requests.post(self.ENDPOINT, data=data,
                                 timeout=app.config["HTTP_TIMEOUT"])
            if resp.status_code != 200:
                return provider_result("PhishTank", ERROR, error="HTTP %s" % resp.status_code)
            j = resp.json()
            res = j.get("results", {})
            in_db = bool(res.get("in_database"))
            valid = bool(res.get("verified")) and bool(res.get("valid"))
            verdict = "MALICIOUS" if (in_db and valid) else "SAFE"
            return provider_result("PhishTank", AVAILABLE, verdict,
                                   80 if verdict == "MALICIOUS" else 0,
                                   {"in_database": in_db, "verified": valid})
        except Exception as exc:
            return provider_result("PhishTank", ERROR, error=str(exc))


# =============================================================================
# Have I Been Pwned
# =============================================================================
class HIBPService:
    BASE = "https://haveibeenpwned.com/api/v3/breachedaccount/"

    def __init__(self, api_key):
        self.api_key = api_key

    def check_email(self, email):
        if app.config["DEMO_MODE"] and not self.api_key:
            seed = sum(ord(c) for c in email)
            breached = (seed % 3 == 0)
            n = (seed % 6) + 1 if breached else 0
            return provider_result(
                "HIBP", AVAILABLE,
                "BREACHED" if breached else "SAFE",
                min(100, n * 15) if breached else 0,
                {"breached": breached, "breach_count": n, "simulated": True},
            )
        if not self.api_key:
            return provider_result("HIBP", NOT_CONFIGURED,
                                   error="HIBP: API key not configured")
        if not _HAS_REQUESTS:
            return provider_result("HIBP", UNAVAILABLE, error="requests unavailable")
        try:
            headers = {"hibp-api-key": self.api_key,
                       "user-agent": "AI-Threat-Orchestrator"}
            resp = _http_get(self.BASE + email, headers=headers,
                             params={"truncateResponse": "true"})
            if resp.status_code == 404:
                return provider_result("HIBP", AVAILABLE, "SAFE", 0,
                                       {"breached": False, "breach_count": 0})
            if resp.status_code == 401:
                return provider_result("HIBP", NOT_CONFIGURED, error="Invalid API key")
            if resp.status_code == 200:
                breaches = resp.json()
                n = len(breaches)
                return provider_result("HIBP", AVAILABLE, "BREACHED",
                                       min(100, n * 15),
                                       {"breached": True, "breach_count": n,
                                        "breaches": [b.get("Name") for b in breaches][:10]})
            return provider_result("HIBP", ERROR, error="HTTP %s" % resp.status_code)
        except Exception as exc:
            return provider_result("HIBP", ERROR, error=str(exc))


# =============================================================================
# DNS analysis (dnspython)
# =============================================================================
class DNSAnalyzer:
    RECORDS = ["A", "AAAA", "MX", "NS", "TXT", "CNAME"]

    def analyze(self, hostname):
        if not hostname:
            return provider_result("DNS", NOT_APPLICABLE)
        if not _HAS_DNS:
            return provider_result("DNS", UNAVAILABLE, error="dnspython not installed")
        found = {}
        try:
            resolver = dns.resolver.Resolver()
            resolver.lifetime = app.config["HTTP_TIMEOUT"]
            resolver.timeout = app.config["HTTP_TIMEOUT"]
            for rtype in self.RECORDS:
                try:
                    answers = resolver.resolve(hostname, rtype)
                    found[rtype] = [str(r) for r in answers][:8]
                except dns.resolver.NoAnswer:
                    continue
                except dns.resolver.NXDOMAIN:
                    return provider_result("DNS", AVAILABLE, "SUSPICIOUS", 40,
                                           {"error": "NXDOMAIN", "records": {}})
                except dns.resolver.NoNameservers:
                    continue
                except Exception:
                    continue
            if not found:
                return provider_result("DNS", AVAILABLE, "SUSPICIOUS", 30,
                                       {"records": {}, "note": "no records"})
            score = 0 if "A" in found or "AAAA" in found else 20
            return provider_result("DNS", AVAILABLE, "NORMAL", score,
                                   {"records": found})
        except Exception as exc:
            return provider_result("DNS", ERROR, error=str(exc))


# =============================================================================
# WHOIS analysis (python-whois)
# =============================================================================
class WHOISAnalyzer:
    def analyze(self, hostname):
        if not hostname:
            return provider_result("WHOIS", NOT_APPLICABLE)
        if not _HAS_WHOIS:
            return provider_result("WHOIS", UNAVAILABLE, error="WHOIS unavailable")
        try:
            w = whois_lib.whois(hostname)

            def _first(x):
                if isinstance(x, (list, tuple)):
                    return x[0] if x else None
                return x

            created = _first(w.creation_date)
            expires = _first(w.expiration_date)
            updated = _first(w.updated_date)
            age_days = None
            score = 0
            verdict = "NORMAL"
            if isinstance(created, dt.datetime):
                age_days = (dt.datetime.now() - created.replace(tzinfo=None)).days
                if age_days < 30:
                    score, verdict = 55, "SUSPICIOUS"
                elif age_days < 180:
                    score, verdict = 30, "SUSPICIOUS"
            details = {
                "registrar": str(w.registrar) if w.registrar else None,
                "creation_date": str(created) if created else None,
                "expiration_date": str(expires) if expires else None,
                "updated_date": str(updated) if updated else None,
                "name_servers": list(w.name_servers)[:6] if w.name_servers else [],
                "status": (w.status if isinstance(w.status, list) else [w.status])
                          if w.status else [],
                "domain_age_days": age_days,
            }
            if not w.registrar and age_days is None:
                return provider_result("WHOIS", UNAVAILABLE, error="WHOIS unavailable")
            return provider_result("WHOIS", AVAILABLE, verdict, score, details)
        except Exception as exc:
            return provider_result("WHOIS", UNAVAILABLE, error="WHOIS unavailable: %s" % exc)


# =============================================================================
# SSL / TLS analysis (stdlib ssl)
# =============================================================================
class SSLAnalyzer:
    def analyze(self, hostname):
        if not hostname:
            return provider_result("SSL", NOT_APPLICABLE)
        # Never probe private / internal targets
        if is_private_target(hostname):
            return provider_result("SSL", NOT_APPLICABLE,
                                   error="Blocked internal/private target")
        try:
            ctx = ssl.create_default_context()
            with socket.create_connection((hostname, 443),
                                          timeout=app.config["HTTP_TIMEOUT"]) as sock:
                with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
                    cert = ssock.getpeercert()
            not_after = cert.get("notAfter")
            expires = None
            days_remaining = None
            if not_after:
                expires = dt.datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z")
                days_remaining = (expires - dt.datetime.utcnow()).days
            subject = dict(x[0] for x in cert.get("subject", []))
            issuer = dict(x[0] for x in cert.get("issuer", []))
            score = 0
            verdict = "VALID"
            if days_remaining is not None and days_remaining < 0:
                score, verdict = 60, "SUSPICIOUS"
            elif days_remaining is not None and days_remaining < 15:
                score, verdict = 25, "SUSPICIOUS"
            return provider_result("SSL", AVAILABLE, verdict, score, {
                "https": True,
                "subject": subject.get("commonName"),
                "issuer": issuer.get("commonName") or issuer.get("organizationName"),
                "expires": str(expires) if expires else None,
                "days_remaining": days_remaining,
            })
        except ssl.SSLError as exc:
            return provider_result("SSL", AVAILABLE, "SUSPICIOUS", 45,
                                   {"https": True, "error": "SSL error: %s" % exc})
        except (socket.timeout, socket.gaierror, ConnectionRefusedError, OSError) as exc:
            return provider_result("SSL", UNAVAILABLE,
                                   details={"https": False}, error=str(exc))
        except Exception as exc:
            return provider_result("SSL", ERROR, error=str(exc))


# =============================================================================
# Risk Engine  (weighted signal correlation with re-normalization)
# =============================================================================
class RiskEngine:
    WEIGHTS = {
        "threat_intel": 0.30,   # VirusTotal + PhishTank + HIBP
        "ml": 0.30,
        "domain": 0.15,         # WHOIS
        "dns": 0.10,
        "url": 0.10,            # URL feature heuristic
        "ssl": 0.05,
    }

    @staticmethod
    def _url_heuristic_score(features):
        """Turn raw URL features into a 0-100 heuristic score (NOT a verdict)."""
        if not features:
            return None
        s = 0
        s += 18 if features.get("has_ip") else 0
        s += 15 if features.get("has_at") else 0
        s += min(20, features.get("suspicious_keywords", 0) * 7)
        s += 12 if features.get("suspicious_tld") else 0
        s += min(10, features.get("subdomain_count", 0) * 4)
        s += 0 if features.get("https") else 10
        s += 8 if features.get("url_length", 0) > 75 else 0
        return min(100, s)

    def correlate(self, signals, ml_result):
        """signals: list of normalized provider_result dicts.
        ml_result: dict from MLModel.predict.
        Returns full correlation object + final score/verdict."""
        by_provider = {s["provider"]: s for s in signals}

        component_scores = {}
        available = []
        unavailable = []

        # ---- Threat Intelligence (max of VT / PhishTank / HIBP available) ----
        ti_scores = []
        for p in ("VirusTotal", "PhishTank", "HIBP"):
            s = by_provider.get(p)
            if s and s["status"] == AVAILABLE:
                ti_scores.append(s["score"])
                available.append(p)
            elif s and s["status"] in (NOT_CONFIGURED, UNAVAILABLE, ERROR):
                unavailable.append(p)
        if ti_scores:
            component_scores["threat_intel"] = max(ti_scores)

        # ---- ML ----
        if ml_result and ml_result.get("available") and ml_result.get("probability") is not None:
            component_scores["ml"] = float(ml_result["probability"])
            available.append("ML")
        else:
            unavailable.append("ML")

        # ---- Domain intelligence (WHOIS) ----
        w = by_provider.get("WHOIS")
        if w and w["status"] == AVAILABLE:
            component_scores["domain"] = w["score"]
            available.append("WHOIS")
        elif w and w["status"] in (UNAVAILABLE, ERROR):
            unavailable.append("WHOIS")

        # ---- DNS ----
        d = by_provider.get("DNS")
        if d and d["status"] == AVAILABLE:
            component_scores["dns"] = d["score"]
            available.append("DNS")
        elif d and d["status"] in (UNAVAILABLE, ERROR):
            unavailable.append("DNS")

        # ---- URL heuristic ----
        url_feats = ml_result.get("features") if ml_result else None
        url_score = self._url_heuristic_score(url_feats)
        if url_score is not None:
            component_scores["url"] = url_score
            available.append("URL")

        # ---- SSL ----
        sl = by_provider.get("SSL")
        if sl and sl["status"] == AVAILABLE:
            component_scores["ssl"] = sl["score"]
            available.append("SSL")
        elif sl and sl["status"] in (UNAVAILABLE, ERROR):
            unavailable.append("SSL")

        # ---- Re-normalize weights over available components ----
        active_weight = sum(self.WEIGHTS[k] for k in component_scores)
        breakdown = []
        final = 0.0
        if active_weight > 0:
            for key, raw in component_scores.items():
                norm_w = self.WEIGHTS[key] / active_weight
                contribution = raw * norm_w
                final += contribution
                breakdown.append({
                    "component": key,
                    "raw_score": round(raw, 1),
                    "base_weight": self.WEIGHTS[key],
                    "normalized_weight": round(norm_w, 3),
                    "weighted_points": round(raw * self.WEIGHTS[key] / active_weight, 1),
                    "max_points": round(self.WEIGHTS[key] / active_weight * 100, 1),
                })
        final = int(round(min(100, max(0, final))))

        verdict = self.verdict_for(final)
        # Confidence heuristic: more available signals -> higher confidence
        confidence = int(min(99, 40 + len(set(available)) * 9))

        return {
            "final_score": final,
            "verdict": verdict,
            "confidence": confidence,
            "breakdown": breakdown,
            "available_signals": sorted(set(available)),
            "unavailable_signals": sorted(set(unavailable)),
            "renormalized": active_weight < 0.999 if component_scores else False,
            "component_scores": {k: round(v, 1) for k, v in component_scores.items()},
        }

    @staticmethod
    def verdict_for(score):
        if score <= 20:
            return "LOW"
        if score <= 40:
            return "MODERATE"
        if score <= 60:
            return "MEDIUM"
        if score <= 80:
            return "HIGH"
        return "CRITICAL"


# =============================================================================
# AIAnalysisEngine  (deterministic, rule-based explanation; LLM-ready)
# =============================================================================
class AIAnalysisEngine:
    """Default provider is a local deterministic explanation engine. Kept as an
    abstraction so an LLM provider can be plugged in later without touching the
    orchestrator."""

    provider = "local-deterministic"

    def explain(self, indicator, itype, signals, ml_result, correlation):
        by = {s["provider"]: s for s in signals}
        factors = []

        vt = by.get("VirusTotal")
        if vt and vt["status"] == AVAILABLE and vt["verdict"] in ("MALICIOUS", "SUSPICIOUS"):
            det = vt["details"].get("detections", 0)
            factors.append("Threat intelligence (VirusTotal) reported %s detection(s)." % det)

        pt = by.get("PhishTank")
        if pt and pt["status"] == AVAILABLE and pt["verdict"] == "MALICIOUS":
            factors.append("PhishTank lists this URL as a known phishing page.")

        hibp = by.get("HIBP")
        if hibp and hibp["status"] == AVAILABLE and hibp["verdict"] == "BREACHED":
            n = hibp["details"].get("breach_count", 0)
            factors.append("Email address appears in %s known data breach(es)." % n)

        w = by.get("WHOIS")
        if w and w["status"] == AVAILABLE:
            age = w["details"].get("domain_age_days")
            if age is not None and age < 180:
                factors.append("The domain appears recently registered (~%s days old)." % age)

        if ml_result and ml_result.get("available") and ml_result.get("probability") is not None:
            if ml_result["probability"] >= 60:
                factors.append("The ML model produced a high malicious probability (%.1f%%)."
                               % ml_result["probability"])

        feats = ml_result.get("features") if ml_result else {}
        url_notes = []
        if feats.get("has_ip"):
            url_notes.append("uses an IP address instead of a hostname")
        if feats.get("has_at"):
            url_notes.append("contains an '@' symbol")
        if feats.get("suspicious_keywords", 0) > 0:
            url_notes.append("contains %d suspicious keyword(s)" % feats["suspicious_keywords"])
        if feats.get("suspicious_tld"):
            url_notes.append("uses a suspicious top-level domain")
        if not feats.get("https") and itype in ("URL", "DOMAIN"):
            url_notes.append("does not use HTTPS")
        if url_notes:
            factors.append("The indicator " + "; ".join(url_notes) + ".")

        ssl_s = by.get("SSL")
        if ssl_s and ssl_s["status"] == AVAILABLE and ssl_s["verdict"] == "SUSPICIOUS":
            factors.append("The SSL/TLS certificate has issues (expired or near expiry).")

        if not factors:
            factors.append("No strong malicious indicators were observed in the available signals.")

        return {
            "provider": self.provider,
            "risk_factors": factors,
            "unavailable": correlation.get("unavailable_signals", []),
        }

    @staticmethod
    def recommendations(verdict):
        if verdict in ("HIGH", "CRITICAL"):
            return [
                "Do not interact with the indicator.",
                "Block the domain/IP at your perimeter where appropriate.",
                "Investigate related endpoints and recent connections.",
                "Review authentication logs for suspicious activity.",
                "Verify the source independently before trusting it.",
            ]
        if verdict in ("MEDIUM", "MODERATE"):
            return [
                "Treat the indicator with caution.",
                "Corroborate with additional threat intelligence sources.",
                "Avoid submitting credentials or sensitive data.",
                "Monitor for related activity.",
            ]
        return [
            "No immediate threat indicators were observed.",
            "Continue normal security monitoring.",
            "Remember a 'safe' result is not an absolute guarantee.",
        ]


# =============================================================================
# PDF Report generator (ReportLab)
# =============================================================================
DISCLAIMER = (
    "This platform is designed for defensive cybersecurity analysis and "
    "authorized security investigations only. Threat intelligence results may "
    "contain false positives or false negatives. A 'safe' result does not "
    "guarantee that an indicator is completely harmless. Users are responsible "
    "for ensuring that investigations are authorized and comply with applicable "
    "laws and policies."
)


class ReportGenerator:
    def generate(self, investigation):
        if not _HAS_PDF:
            raise RuntimeError("reportlab not available")
        data = investigation.result()
        buf = io.BytesIO()
        doc = SimpleDocTemplate(buf, pagesize=A4, topMargin=18 * mm,
                                bottomMargin=18 * mm)
        styles = getSampleStyleSheet()
        h1 = ParagraphStyle("h1", parent=styles["Heading1"], textColor=colors.HexColor("#0b3d91"))
        h2 = ParagraphStyle("h2", parent=styles["Heading2"], textColor=colors.HexColor("#12467a"))
        small = ParagraphStyle("small", parent=styles["Normal"], fontSize=8,
                               textColor=colors.grey)
        story = []

        story.append(Paragraph("AI-Powered Threat Orchestrator", h1))
        story.append(Paragraph("Security Investigation Report", styles["Heading3"]))
        story.append(Spacer(1, 6))

        meta = [
            ["Investigation ID", investigation.public_id],
            ["Date", investigation.created_at.strftime("%Y-%m-%d %H:%M UTC")],
            ["Indicator", investigation.indicator_value[:80]],
            ["Indicator Type", investigation.indicator_type],
            ["Mode", investigation.mode],
            ["Risk Score", "%s / 100" % investigation.risk_score],
            ["Verdict", investigation.verdict],
            ["Confidence", "%s%%" % investigation.confidence],
        ]
        t = Table(meta, colWidths=[45 * mm, 120 * mm])
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#eef3fb")),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#c9d6ea")),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ]))
        story.append(t)
        story.append(Spacer(1, 10))

        # Threat intelligence table
        story.append(Paragraph("Threat Intelligence & Signals", h2))
        rows = [["Provider", "Status", "Verdict", "Score"]]
        for s in data.get("signals", []):
            rows.append([s.get("provider"), s.get("status"),
                         s.get("verdict"), str(round(s.get("score", 0), 1))])
        tt = Table(rows, colWidths=[40 * mm, 40 * mm, 45 * mm, 30 * mm])
        tt.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0b3d91")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#c9d6ea")),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
        ]))
        story.append(tt)
        story.append(Spacer(1, 10))

        # ML prediction
        ml = data.get("ml", {})
        story.append(Paragraph("ML Prediction", h2))
        story.append(Paragraph(
            "Prediction: %s &nbsp; | &nbsp; Malicious Probability: %s &nbsp; | &nbsp; Confidence: %s"
            % (ml.get("prediction", "n/a"),
               ("%.1f%%" % ml["probability"]) if ml.get("probability") is not None else "n/a",
               ("%.1f%%" % ml["confidence"]) if ml.get("confidence") is not None else "n/a"),
            styles["Normal"]))
        story.append(Spacer(1, 8))

        # Risk factors
        story.append(Paragraph("Risk Factors", h2))
        for f in data.get("explanation", {}).get("risk_factors", []):
            story.append(Paragraph("&bull; " + f, styles["Normal"]))
        story.append(Spacer(1, 8))

        # Recommendations
        story.append(Paragraph("Security Recommendations", h2))
        for r in data.get("recommendations", []):
            story.append(Paragraph("&bull; " + r, styles["Normal"]))
        story.append(Spacer(1, 8))

        # Provider availability
        corr = data.get("correlation", {})
        story.append(Paragraph("Provider Availability", h2))
        story.append(Paragraph("Available: " + ", ".join(corr.get("available_signals", []) or ["-"]),
                               styles["Normal"]))
        story.append(Paragraph("Unavailable: " + ", ".join(corr.get("unavailable_signals", []) or ["-"]),
                               styles["Normal"]))
        story.append(Spacer(1, 12))

        story.append(Paragraph("Disclaimer", h2))
        story.append(Paragraph(DISCLAIMER, small))

        doc.build(story)
        buf.seek(0)
        return buf


# =============================================================================
# Payment gateways (abstraction + demo mode)
# =============================================================================
class BasePaymentGateway:
    name = "base"

    def __init__(self, config):
        self.config = config

    def configured(self):
        return False

    def mode(self):
        if self.configured() and not app.config["PAYMENT_DEMO_MODE"]:
            return "PRODUCTION"
        if self.configured():
            return "SANDBOX"
        return "DEMO"

    def _demo_txn(self, plan):
        txn = "DEMO-{}-{:04d}".format(self.name.upper(), random.randint(0, 9999))
        return {
            "success": True,
            "transaction_id": txn,
            "status": "success",
            "is_demo": True,
            "message": "DEMO PAYMENT. No real money was charged.",
            "amount": PLANS[plan]["price"],
            "currency": "PKR",
        }

    def create_payment(self, plan, user):
        raise NotImplementedError


class EasypaisaPaymentGateway(BasePaymentGateway):
    name = "easypaisa"

    def configured(self):
        return bool(self.config.get("EASYPAISA_MERCHANT_ID") and
                    self.config.get("EASYPAISA_API_KEY"))

    def create_payment(self, plan, user):
        # Demo / unconfigured -> safe simulated transaction
        if self.mode() in ("DEMO", "SANDBOX") or app.config["PAYMENT_DEMO_MODE"]:
            return self._demo_txn(plan)
        # Production integration requires merchant onboarding (see README).
        return {
            "success": False,
            "status": "failure",
            "is_demo": False,
            "message": "Easypaisa production integration requires merchant onboarding.",
        }


class JazzCashPaymentGateway(BasePaymentGateway):
    name = "jazzcash"

    def configured(self):
        return bool(self.config.get("JAZZCASH_MERCHANT_ID") and
                    self.config.get("JAZZCASH_PASSWORD") and
                    self.config.get("JAZZCASH_INTEGRITY_SALT"))

    def create_payment(self, plan, user):
        if self.mode() in ("DEMO", "SANDBOX") or app.config["PAYMENT_DEMO_MODE"]:
            return self._demo_txn(plan)
        return {
            "success": False,
            "status": "failure",
            "is_demo": False,
            "message": "JazzCash production integration requires merchant onboarding.",
        }


# =============================================================================
# Threat Orchestrator  (coordinates the full investigation pipeline)
# =============================================================================
class ThreatOrchestrator:
    def __init__(self):
        self.vt = VirusTotalService(app.config["VIRUSTOTAL_API_KEY"])
        self.pt = PhishTankService(app.config["PHISHTANK_API_KEY"])
        self.hibp = HIBPService(app.config["HIBP_API_KEY"])
        self.dns = DNSAnalyzer()
        self.whois = WHOISAnalyzer()
        self.ssl = SSLAnalyzer()
        self.risk = RiskEngine()
        self.ai = AIAnalysisEngine()

    def applicable_providers(self, itype):
        """Only call services relevant to the indicator type (performance)."""
        mapping = {
            "URL": ["VirusTotal", "PhishTank", "DNS", "WHOIS", "SSL", "ML"],
            "DOMAIN": ["VirusTotal", "DNS", "WHOIS", "SSL", "ML"],
            "IP": ["VirusTotal", "DNS", "ML"],
            "EMAIL": ["HIBP"],
            "HASH": ["VirusTotal"],
            "TEXT": ["ML"],
        }
        return mapping.get(itype, ["ML"])

    def investigate(self, raw_value, user):
        signals = []

        # 1. validate
        ok, msg = validate_indicator(raw_value)
        if not ok:
            return {"error": msg}

        # 2. detect type  3. normalize
        itype = detect_indicator_type(raw_value)
        norm = normalize_indicator(raw_value, itype)
        hostname = extract_hostname(norm, itype)

        # SSRF guard: block network probing of private/internal targets
        if hostname and is_private_target(hostname):
            return {"error": "Target resolves to a private/internal address and was blocked."}

        providers = self.applicable_providers(itype)

        # 5/6. execute applicable modules, isolating each failure
        def safe(fn, *a):
            try:
                return fn(*a)
            except Exception as exc:
                log.warning("provider error: %s", exc)
                return provider_result("Unknown", ERROR, error=str(exc))

        if "VirusTotal" in providers:
            if itype == "URL":
                signals.append(safe(self.vt.analyze_url, norm))
            elif itype == "DOMAIN":
                signals.append(safe(self.vt.analyze_domain, hostname))
            elif itype == "IP":
                signals.append(safe(self.vt.analyze_ip, norm))
            elif itype == "HASH":
                signals.append(safe(self.vt.analyze_hash, norm))
        if "PhishTank" in providers and itype == "URL":
            signals.append(safe(self.pt.analyze_url, norm))
        if "HIBP" in providers and itype == "EMAIL":
            signals.append(safe(self.hibp.check_email, norm))
        if "DNS" in providers and hostname:
            signals.append(safe(self.dns.analyze, hostname if itype != "IP" else None)
                           if itype != "IP" else provider_result("DNS", NOT_APPLICABLE))
        if "WHOIS" in providers and hostname and itype in ("URL", "DOMAIN"):
            signals.append(safe(self.whois.analyze, hostname))
        if "SSL" in providers and hostname and itype in ("URL", "DOMAIN"):
            signals.append(safe(self.ssl.analyze, hostname))

        # 8/9. ML feature extraction + prediction
        ml_result = ML.predict(norm, itype)

        # 10. correlate + calculate risk
        correlation = self.risk.correlate(signals, ml_result)

        # 11. explanation + recommendations
        explanation = self.ai.explain(norm, itype, signals, ml_result, correlation)
        recommendations = self.ai.recommendations(correlation["verdict"])

        mode = "DEMO" if app.config["DEMO_MODE"] else "LIVE"

        result = {
            "indicator": norm,
            "indicator_type": itype,
            "hash_kind": hash_kind(norm) if itype == "HASH" else None,
            "hostname": hostname,
            "mode": mode,
            "signals": signals,
            "ml": ml_result,
            "correlation": correlation,
            "explanation": explanation,
            "recommendations": recommendations,
            "risk_score": correlation["final_score"],
            "verdict": correlation["verdict"],
            "confidence": correlation["confidence"],
        }

        # 12. persist
        inv = self._save(user, raw_value, norm, itype, result)
        result["investigation_id"] = inv.public_id
        result["timestamp"] = inv.created_at.strftime("%Y-%m-%d %H:%M UTC")
        return result

    def _save(self, user, raw_value, norm, itype, result):
        pid = "INV-" + dt.datetime.utcnow().strftime("%y%m%d") + "-" + \
              "".join(random.choices("ABCDEFGHJKLMNPQRSTUVWXYZ23456789", k=6))
        inv = Investigation(
            public_id=pid, user_id=user.id, indicator_value=norm[:600],
            indicator_type=itype, risk_score=result["risk_score"],
            verdict=result["verdict"], confidence=result["confidence"],
            mode=result["mode"], result_json=json.dumps(result, default=str),
        )
        db.session.add(inv)
        db.session.flush()

        db.session.add(Indicator(investigation_id=inv.id, value=norm[:600],
                                 itype=itype, normalized=norm[:600]))
        for s in result["signals"]:
            db.session.add(ThreatResult(
                investigation_id=inv.id, provider=s["provider"], status=s["status"],
                verdict=s["verdict"], score=s["score"],
                details_json=json.dumps(s["details"], default=str)))
        ml = result["ml"]
        db.session.add(MLPrediction(
            investigation_id=inv.id, prediction=ml.get("prediction"),
            probability=ml.get("probability") or 0.0,
            confidence=ml.get("confidence") or 0.0,
            features_json=json.dumps(ml.get("features", {}), default=str)))

        # usage accounting
        user.ensure_period()
        user.scans_used += 1
        db.session.commit()

        # notifications for high-risk findings
        if result["verdict"] in ("HIGH", "CRITICAL"):
            notify(user.id, "Critical threat detected",
                   "%s flagged as %s (score %s)." % (norm[:60], result["verdict"],
                                                     result["risk_score"]),
                   "critical")
        if user.remaining_scans() <= 1:
            notify(user.id, "Scan limit almost reached",
                   "You are close to your monthly scan limit.", "warning")

        audit("investigation", indicator=norm,
              result="%s/%s" % (result["risk_score"], result["verdict"]),
              user_id=user.id)
        return inv


ORCH = ThreatOrchestrator()


# =============================================================================
# Auth helpers
# =============================================================================
def current_user():
    uid = session.get("uid")
    if not uid:
        return None
    return db.session.get(User, uid)


def login_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if not session.get("uid"):
            if request.path.startswith("/api/"):
                return jsonify({"error": "authentication required"}), 401
            return redirect(url_for("login"))
        return fn(*a, **kw)
    return wrapper


def admin_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        u = current_user()
        if not u or u.role != "admin":
            if request.path.startswith("/api/"):
                return jsonify({"error": "admin only"}), 403
            abort(403)
        return fn(*a, **kw)
    return wrapper


@app.context_processor
def inject_globals():
    u = current_user()
    unread = 0
    if u:
        unread = Notification.query.filter_by(user_id=u.id, is_read=False).count()
    return {
        "current_user": u,
        "DEMO_MODE": app.config["DEMO_MODE"],
        "unread_notifications": unread,
        "product_name": "AI-Powered Threat Orchestrator",
        "product_short": "Threat Orchestrator",
        "tagline": "AI-Assisted Threat Intelligence & Automated Security Investigation",
    }


def provider_status_map():
    """Configuration status for each provider (no secrets revealed)."""
    return {
        "VirusTotal": bool(app.config["VIRUSTOTAL_API_KEY"]),
        "PhishTank": bool(app.config["PHISHTANK_API_KEY"]),
        "HIBP": bool(app.config["HIBP_API_KEY"]),
        "Easypaisa": bool(app.config["EASYPAISA_MERCHANT_ID"] and app.config["EASYPAISA_API_KEY"]),
        "JazzCash": bool(app.config["JAZZCASH_MERCHANT_ID"] and app.config["JAZZCASH_PASSWORD"]),
        "DNS": _HAS_DNS,
        "WHOIS": _HAS_WHOIS,
        "SSL": True,
    }


# =============================================================================
# Embedded frontend (dark SOC theme)  -  rendered via render_template_string
# =============================================================================
BASE_CSS = """
:root{
  --bg:#0a0e17; --bg2:#0f1523; --panel:#131b2e; --panel2:#182135;
  --border:#243049; --text:#e6ecf5; --muted:#8ea0be; --accent:#3b82f6;
  --accent2:#22d3ee; --good:#22c55e; --warn:#f59e0b; --bad:#ef4444;
  --crit:#dc2626; --mod:#84cc16;
}
*{box-sizing:border-box}
body{margin:0;font-family:'Segoe UI',system-ui,Roboto,Arial,sans-serif;
  background:radial-gradient(1200px 600px at 80% -10%,#12203a 0%,var(--bg) 55%);
  color:var(--text);min-height:100vh}
a{color:var(--accent2);text-decoration:none}
.layout{display:flex;min-height:100vh}
.sidebar{width:238px;background:linear-gradient(180deg,#0d1424,#0a0e17);
  border-right:1px solid var(--border);padding:18px 12px;position:sticky;top:0;height:100vh}
.brand{display:flex;align-items:center;gap:10px;font-weight:700;font-size:15px;margin-bottom:4px}
.brand .logo{width:30px;height:30px;border-radius:8px;
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  display:flex;align-items:center;justify-content:center;font-size:16px}
.brand small{display:block;color:var(--muted);font-weight:400;font-size:10px}
.nav{margin-top:18px;display:flex;flex-direction:column;gap:2px}
.nav a{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:9px;
  color:var(--muted);font-size:14px;transition:.15s}
.nav a:hover{background:var(--panel);color:var(--text)}
.nav a.active{background:linear-gradient(90deg,rgba(59,130,246,.18),transparent);
  color:#fff;border-left:3px solid var(--accent)}
.nav .badge{margin-left:auto;background:var(--bad);color:#fff;border-radius:10px;
  padding:1px 7px;font-size:11px}
.main{flex:1;display:flex;flex-direction:column;min-width:0}
.topbar{display:flex;align-items:center;gap:14px;padding:14px 26px;
  border-bottom:1px solid var(--border);background:rgba(15,21,35,.6);backdrop-filter:blur(8px);
  position:sticky;top:0;z-index:5}
.topbar h1{font-size:17px;margin:0}
.spacer{flex:1}
.pill{padding:5px 12px;border-radius:20px;font-size:12px;font-weight:600;
  border:1px solid var(--border);background:var(--panel)}
.pill.demo{color:var(--warn);border-color:#4a3b12;background:#1f1a0a}
.pill.live{color:var(--good);border-color:#123a1f}
.content{padding:26px;max-width:1200px;width:100%}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px}
.card{background:var(--panel);border:1px solid var(--border);border-radius:14px;padding:18px}
.card h3{margin:0 0 6px;font-size:13px;color:var(--muted);font-weight:600;text-transform:uppercase;letter-spacing:.5px}
.card .big{font-size:30px;font-weight:700}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:18px}
.grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
@media(max-width:900px){.grid2,.grid3{grid-template-columns:1fr}.sidebar{display:none}}
.panel{background:var(--panel);border:1px solid var(--border);border-radius:14px;padding:20px;margin-bottom:18px}
.panel h2{margin:0 0 14px;font-size:16px}
input,select,textarea{width:100%;padding:12px 14px;background:var(--bg2);
  border:1px solid var(--border);border-radius:10px;color:var(--text);font-size:14px;outline:none}
input:focus,textarea:focus{border-color:var(--accent)}
label{display:block;margin:12px 0 6px;font-size:13px;color:var(--muted)}
.btn{display:inline-flex;align-items:center;gap:8px;padding:11px 18px;border:none;border-radius:10px;
  background:linear-gradient(135deg,var(--accent),#2563eb);color:#fff;font-weight:600;font-size:14px;
  cursor:pointer;transition:.15s}
.btn:hover{filter:brightness(1.1)}
.btn.ghost{background:var(--panel2);border:1px solid var(--border)}
.btn.full{width:100%;justify-content:center}
.btn.danger{background:linear-gradient(135deg,#ef4444,#b91c1c)}
table{width:100%;border-collapse:collapse;font-size:13px}
th,td{text-align:left;padding:11px 12px;border-bottom:1px solid var(--border)}
th{color:var(--muted);font-weight:600;font-size:12px;text-transform:uppercase}
tr:hover td{background:rgba(255,255,255,.02)}
.badge-v{padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700}
.v-LOW,.v-SAFE,.v-VALID,.v-NORMAL{background:#123a1f;color:#4ade80}
.v-MODERATE{background:#2a3512;color:#a3e635}
.v-MEDIUM,.v-SUSPICIOUS{background:#3a2e0a;color:#fbbf24}
.v-HIGH{background:#3a1a0a;color:#fb923c}
.v-CRITICAL,.v-MALICIOUS,.v-BREACHED{background:#3a0f0f;color:#f87171}
.v-UNAVAILABLE,.v-NOT_CONFIGURED,.v-NOT_APPLICABLE,.v-ERROR{background:#1c2436;color:#8ea0be}
.muted{color:var(--muted)}
.flash{padding:12px 16px;border-radius:10px;margin-bottom:14px;font-size:14px}
.flash.error{background:#3a0f0f;color:#f87171;border:1px solid #5a1a1a}
.flash.success{background:#0f2a1a;color:#4ade80;border:1px solid #1a4a2a}
.auth-wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.auth-card{width:100%;max-width:420px;background:var(--panel);border:1px solid var(--border);
  border-radius:18px;padding:34px}
.auth-card .brand{justify-content:center;font-size:19px;margin-bottom:8px}
.gauge-wrap{text-align:center}
.gauge{position:relative;width:200px;height:200px;margin:0 auto}
.gauge svg{transform:rotate(-90deg)}
.gauge .num{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center}
.gauge .num b{font-size:44px}
.progress-list{list-style:none;padding:0;margin:0}
.progress-list li{padding:9px 0;color:var(--muted);border-bottom:1px solid var(--border);
  display:flex;align-items:center;gap:10px;font-size:14px}
.progress-list li.done{color:var(--good)}
.progress-list li.active{color:var(--accent2)}
.dot{width:9px;height:9px;border-radius:50%;background:var(--border)}
.progress-list li.done .dot{background:var(--good)}
.progress-list li.active .dot{background:var(--accent2);animation:pulse 1s infinite}
@keyframes pulse{50%{opacity:.3}}
.bar{height:8px;background:var(--bg2);border-radius:6px;overflow:hidden;margin-top:6px}
.bar span{display:block;height:100%;background:linear-gradient(90deg,var(--accent),var(--accent2))}
.tag{display:inline-block;padding:3px 9px;border-radius:6px;background:var(--panel2);
  border:1px solid var(--border);font-size:11px;margin:2px}
.kv{display:grid;grid-template-columns:160px 1fr;gap:8px 14px;font-size:13px}
.kv div:nth-child(odd){color:var(--muted)}
.plan{border:1px solid var(--border);border-radius:14px;padding:22px;background:var(--panel)}
.plan.featured{border-color:var(--accent);box-shadow:0 0 0 1px var(--accent)}
.plan .price{font-size:30px;font-weight:700;margin:8px 0}
.toast{position:fixed;bottom:20px;right:20px;background:var(--panel);border:1px solid var(--border);
  padding:14px 18px;border-radius:12px;display:none;z-index:50}
"""

NAV_ITEMS = [
    ("dashboard", "Dashboard", "\U0001F4CA"),
    ("new_investigation", "New Investigation", "\U0001F50D"),
    ("history", "Investigation History", "\U0001F4DC"),
    ("threat_intel", "Threat Intelligence", "\U0001F6E1"),
    ("ml_center", "Machine Learning", "\U0001F9E0"),
    ("billing", "Billing", "\U0001F4B3"),
    ("notifications", "Notifications", "\U0001F514"),
    ("settings", "Settings", "\u2699"),
]

BASE_HTML = """
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token_value }}">
<title>{{ product_short }} - {{ title }}</title>
<style>{{ css }}</style>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
</head><body>
<div class="layout">
  <aside class="sidebar">
    <div class="brand"><div class="logo">\U0001F6E1</div><div>Threat Orchestrator
      <small>Security Brain</small></div></div>
    <nav class="nav">
      {% for key,label,icon in nav_items %}
      <a href="{{ url_for(key) }}" class="{{ 'active' if active==key else '' }}">
        <span>{{ icon }}</span>{{ label }}
        {% if key=='notifications' and unread_notifications %}<span class="badge">{{ unread_notifications }}</span>{% endif %}
      </a>
      {% endfor %}
      {% if current_user and current_user.role=='admin' %}
      <a href="{{ url_for('admin') }}" class="{{ 'active' if active=='admin' else '' }}"><span>\U0001F510</span>Admin Panel</a>
      {% endif %}
      <a href="{{ url_for('logout') }}"><span>\U0001F6AA</span>Logout</a>
    </nav>
  </aside>
  <div class="main">
    <div class="topbar">
      <h1>{{ title }}</h1><div class="spacer"></div>
      <span class="pill {{ 'demo' if DEMO_MODE else 'live' }}">{{ 'DEMO MODE' if DEMO_MODE else 'LIVE MODE' }}</span>
      {% if current_user %}<span class="pill">{{ current_user.name }} &middot; {{ current_user.plan|upper }}</span>{% endif %}
    </div>
    <div class="content">
      {% with msgs = get_flashed_messages(with_categories=true) %}
        {% for cat,m in msgs %}<div class="flash {{ cat }}">{{ m }}</div>{% endfor %}
      {% endwith %}
      {% if DEMO_MODE %}<div class="flash" style="background:#1f1a0a;color:#fbbf24;border:1px solid #4a3b12">
        <b>DEMO MODE ACTIVE.</b> External provider data may be simulated for academic demonstration. Simulated results are labelled and never presented as real threat intelligence.</div>{% endif %}
      {{ body|safe }}
    </div>
  </div>
</div>
<div class="toast" id="toast"></div>
<script>
function csrfToken(){var m=document.querySelector('meta[name=csrf-token]');return m?m.content:'';}
function toast(msg){var t=document.getElementById('toast');t.textContent=msg;t.style.display='block';
  setTimeout(function(){t.style.display='none';},3200);}
</script>
{{ extra_js|safe }}
</body></html>
"""


def render(title, active, body, extra_js=""):
    token = ""
    try:
        if _HAS_CSRF:
            from flask_wtf.csrf import generate_csrf
            token = generate_csrf()
    except Exception:
        token = ""
    return render_template_string(
        BASE_HTML, title=title, active=active, body=body, css=BASE_CSS,
        nav_items=NAV_ITEMS, extra_js=extra_js, csrf_token_value=token,
    )


# =============================================================================
# Auth routes
# =============================================================================
AUTH_PAGE = """
<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token_value }}">
<title>{{ product_name }}</title><style>{{ css }}</style></head><body>
<div class="auth-wrap"><div class="auth-card">
  <div class="brand"><div class="logo">\U0001F6E1</div><div>{{ product_name }}</div></div>
  <p class="muted" style="text-align:center;font-size:13px;margin-top:0">{{ tagline }}</p>
  {% with msgs = get_flashed_messages(with_categories=true) %}
    {% for cat,m in msgs %}<div class="flash {{ cat }}">{{ m }}</div>{% endfor %}
  {% endwith %}
  <form method="post" action="{{ action }}">
    <input type="hidden" name="csrf_token" value="{{ csrf_token_value }}">
    {% if mode=='register' %}
    <label>Full Name</label><input name="name" required>
    {% endif %}
    <label>Email</label><input type="email" name="email" required>
    <label>Password</label><input type="password" name="password" required minlength="6">
    <div style="height:16px"></div>
    <button class="btn full">{{ 'Create Account' if mode=='register' else 'Login' }}</button>
  </form>
  <p class="muted" style="text-align:center;margin-top:16px;font-size:13px">
    {% if mode=='register' %}Already have an account? <a href="{{ url_for('login') }}">Login</a>
    {% else %}No account? <a href="{{ url_for('register') }}">Register</a>{% endif %}
  </p>
</div></div></body></html>
"""


def render_auth(mode, action):
    token = ""
    try:
        if _HAS_CSRF:
            from flask_wtf.csrf import generate_csrf
            token = generate_csrf()
    except Exception:
        token = ""
    return render_template_string(
        AUTH_PAGE, css=BASE_CSS, mode=mode, action=action,
        product_name="AI-Powered Threat Orchestrator",
        tagline="AI-Assisted Threat Intelligence & Automated Security Investigation",
        csrf_token_value=token,
    )


@app.route("/")
def index():
    if session.get("uid"):
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/register", methods=["GET", "POST"])
@rate_limit("20 per hour")
def register():
    if request.method == "POST":
        name = (request.form.get("name") or "").strip()
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""
        if not name or not EMAIL_RE.match(email) or len(password) < 6:
            flash("Please provide a valid name, email and password (min 6 chars).", "error")
            return render_auth("register", url_for("register"))
        if User.query.filter_by(email=email).first():
            flash("An account with that email already exists.", "error")
            return render_auth("register", url_for("register"))
        u = User(name=name, email=email, role="user", plan="free")
        u.set_password(password)
        db.session.add(u)
        db.session.commit()
        notify(u.id, "Welcome to Threat Orchestrator",
               "Your account is ready. Start your first investigation.", "success")
        audit("register", user_id=u.id)
        session["uid"] = u.id
        flash("Account created. Welcome!", "success")
        return redirect(url_for("dashboard"))
    return render_auth("register", url_for("register"))


@app.route("/login", methods=["GET", "POST"])
@rate_limit("30 per hour")
def login():
    if request.method == "POST":
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""
        u = User.query.filter_by(email=email).first()
        if not u or not u.check_password(password):
            audit("login_failed", indicator=email)
            flash("Invalid email or password.", "error")
            return render_auth("login", url_for("login"))
        session["uid"] = u.id
        session.permanent = False
        audit("login", user_id=u.id)
        return redirect(url_for("dashboard"))
    return render_auth("login", url_for("login"))


@app.route("/logout")
def logout():
    if session.get("uid"):
        audit("logout")
    session.clear()
    return redirect(url_for("login"))


# =============================================================================
# Dashboard
# =============================================================================
def _gauge_svg(score):
    verdict = RiskEngine.verdict_for(score)
    color = {"LOW": "#22c55e", "MODERATE": "#84cc16", "MEDIUM": "#f59e0b",
             "HIGH": "#fb923c", "CRITICAL": "#ef4444"}[verdict]
    circumference = 2 * math.pi * 80
    offset = circumference * (1 - score / 100.0)
    return """
    <div class="gauge">
      <svg width="200" height="200" viewBox="0 0 200 200">
        <circle cx="100" cy="100" r="80" stroke="#243049" stroke-width="16" fill="none"/>
        <circle cx="100" cy="100" r="80" stroke="{color}" stroke-width="16" fill="none"
          stroke-linecap="round" stroke-dasharray="{circ}" stroke-dashoffset="{off}"/>
      </svg>
      <div class="num"><b style="color:{color}">{score}</b>
        <span class="muted">/ 100</span>
        <span class="badge-v v-{verdict}" style="margin-top:8px">{verdict}</span></div>
    </div>""".format(color=color, circ=circumference, off=offset, score=score, verdict=verdict)


@app.route("/dashboard")
@login_required
def dashboard():
    u = current_user()
    q = Investigation.query.filter_by(user_id=u.id)
    total = q.count()
    malicious = q.filter(Investigation.verdict.in_(["HIGH", "CRITICAL"])).count()
    suspicious = q.filter(Investigation.verdict.in_(["MEDIUM", "MODERATE"])).count()
    safe = q.filter(Investigation.verdict == "LOW").count()
    today = dt.datetime.utcnow().date()
    threats_today = q.filter(
        Investigation.verdict.in_(["HIGH", "CRITICAL"]),
        Investigation.created_at >= dt.datetime(today.year, today.month, today.day)
    ).count()

    recent = q.order_by(Investigation.created_at.desc()).limit(6).all()

    # chart data
    dist = {"LOW": safe, "MODERATE": 0, "MEDIUM": 0, "HIGH": 0, "CRITICAL": 0}
    for inv in q.all():
        dist[inv.verdict] = dist.get(inv.verdict, 0) + 1

    # last 7 days activity
    days = [(today - dt.timedelta(days=i)) for i in range(6, -1, -1)]
    activity = []
    for d in days:
        start = dt.datetime(d.year, d.month, d.day)
        end = start + dt.timedelta(days=1)
        activity.append(q.filter(Investigation.created_at >= start,
                                 Investigation.created_at < end).count())

    rows = ""
    for inv in recent:
        rows += """<tr><td><a href="{u}">{ind}</a></td><td>{t}</td>
          <td>{s}</td><td><span class="badge-v v-{v}">{v}</span></td>
          <td class="muted">{d}</td></tr>""".format(
            u=url_for("view_investigation", pid=inv.public_id),
            ind=(inv.indicator_value[:44] + ("..." if len(inv.indicator_value) > 44 else "")),
            t=inv.indicator_type, s=inv.risk_score, v=inv.verdict,
            d=inv.created_at.strftime("%Y-%m-%d %H:%M"))
    if not rows:
        rows = '<tr><td colspan="5" class="muted">No investigations yet. Start one!</td></tr>'

    body = """
    <div class="cards">
      <div class="card"><h3>Total Scans</h3><div class="big">{total}</div></div>
      <div class="card"><h3>Malicious Detected</h3><div class="big" style="color:#f87171">{mal}</div></div>
      <div class="card"><h3>Suspicious</h3><div class="big" style="color:#fbbf24">{sus}</div></div>
      <div class="card"><h3>Safe Indicators</h3><div class="big" style="color:#4ade80">{safe}</div></div>
      <div class="card"><h3>Threats Today</h3><div class="big" style="color:#fb923c">{today}</div></div>
    </div>
    <div style="height:18px"></div>
    <div class="grid3">
      <div class="panel"><h2>Threat Distribution</h2><canvas id="distChart" height="200"></canvas></div>
      <div class="panel"><h2>Scan Activity (7d)</h2><canvas id="actChart" height="200"></canvas></div>
      <div class="panel"><h2>Risk Distribution</h2><canvas id="riskChart" height="200"></canvas></div>
    </div>
    <div class="panel"><h2>Recent Investigations</h2>
      <table><thead><tr><th>Indicator</th><th>Type</th><th>Score</th><th>Verdict</th><th>Date</th></tr></thead>
      <tbody>{rows}</tbody></table>
      <div style="margin-top:14px"><a class="btn" href="{new}">+ New Investigation</a></div>
    </div>
    """.format(total=total, mal=malicious, sus=suspicious, safe=safe, today=threats_today,
               rows=rows, new=url_for("new_investigation"))

    js = """<script>
    if(window.Chart){
      var dist=%s, act=%s, labels=%s;
      new Chart(document.getElementById('distChart'),{type:'doughnut',
        data:{labels:['Low','Moderate','Medium','High','Critical'],
        datasets:[{data:dist,backgroundColor:['#22c55e','#84cc16','#f59e0b','#fb923c','#ef4444']}]},
        options:{plugins:{legend:{labels:{color:'#8ea0be'}}}}});
      new Chart(document.getElementById('actChart'),{type:'line',
        data:{labels:labels,datasets:[{label:'Scans',data:act,borderColor:'#22d3ee',
        backgroundColor:'rgba(34,211,238,.15)',fill:true,tension:.35}]},
        options:{plugins:{legend:{display:false}},scales:{x:{ticks:{color:'#8ea0be'}},y:{ticks:{color:'#8ea0be'}}}}});
      new Chart(document.getElementById('riskChart'),{type:'bar',
        data:{labels:['Low','Mod','Med','High','Crit'],datasets:[{data:dist,
        backgroundColor:['#22c55e','#84cc16','#f59e0b','#fb923c','#ef4444']}]},
        options:{plugins:{legend:{display:false}},scales:{x:{ticks:{color:'#8ea0be'}},y:{ticks:{color:'#8ea0be'}}}}});
    }</script>""" % (
        json.dumps([dist["LOW"], dist["MODERATE"], dist["MEDIUM"], dist["HIGH"], dist["CRITICAL"]]),
        json.dumps(activity),
        json.dumps([d.strftime("%m/%d") for d in days]),
    )
    return render("Dashboard", "dashboard", body, js)


# =============================================================================
# New investigation + result
# =============================================================================
@app.route("/investigation/new")
@login_required
def new_investigation():
    u = current_user()
    remaining = u.remaining_scans()
    body = """
    <div class="panel">
      <h2>New Security Investigation</h2>
      <p class="muted">Enter a URL, Domain, IP, Email, File Hash, or suspicious text. The
      type is detected automatically and only relevant providers are queried.</p>
      <label>Indicator</label>
      <input id="indicator" placeholder="https://example.com/login  |  8.8.8.8  |  test@example.com  |  &lt;md5/sha1/sha256&gt;">
      <div class="muted" style="margin-top:8px">Detected Type: <b id="detType">-</b></div>
      <div style="margin-top:6px" class="muted">Scans remaining this month: <b>{rem}</b> / {lim}</div>
      <div style="height:16px"></div>
      <button class="btn" id="startBtn" onclick="startInvestigation()">\U0001F50D START SECURITY ANALYSIS</button>
    </div>
    <div class="panel" id="progressPanel" style="display:none">
      <h2>Investigation In Progress</h2>
      <ul class="progress-list" id="steps"></ul>
    </div>
    """.format(rem=remaining, lim=u.plan_limit())

    js = """<script>
    var STEPS=["Initializing investigation...","Validating indicator...","Identifying indicator type...",
      "Checking threat intelligence...","Analyzing DNS...","Checking WHOIS...","Analyzing SSL/TLS...",
      "Extracting ML features...","Running ML classification...","Correlating security signals...",
      "Calculating risk...","Generating final verdict..."];
    var indEl=document.getElementById('indicator');
    indEl.addEventListener('input',function(){
      var v=indEl.value.trim();
      if(!v){document.getElementById('detType').textContent='-';return;}
      fetch('/api/detect?value='+encodeURIComponent(v))
        .then(r=>r.json()).then(d=>{document.getElementById('detType').textContent=d.type||'-';});
    });
    function startInvestigation(){
      var v=indEl.value.trim(); if(!v){toast('Enter an indicator first');return;}
      document.getElementById('startBtn').disabled=true;
      var panel=document.getElementById('progressPanel');panel.style.display='block';
      var ul=document.getElementById('steps');ul.innerHTML='';
      STEPS.forEach(function(s,i){var li=document.createElement('li');
        li.innerHTML='<span class="dot"></span>'+s;li.id='step'+i;ul.appendChild(li);});
      var i=0;var iv=setInterval(function(){
        if(i>0)document.getElementById('step'+(i-1)).className='done';
        if(i<STEPS.length){document.getElementById('step'+i).className='active';i++;}
        else clearInterval(iv);
      },260);
      fetch('/api/investigate',{method:'POST',headers:{'Content-Type':'application/json',
        'X-CSRFToken':csrfToken()},body:JSON.stringify({indicator:v})})
        .then(r=>r.json()).then(function(d){
          clearInterval(iv);
          if(d.error){toast(d.error);document.getElementById('startBtn').disabled=false;
            panel.style.display='none';return;}
          for(var k=0;k<STEPS.length;k++)document.getElementById('step'+k).className='done';
          setTimeout(function(){window.location='/investigation/'+d.investigation_id;},500);
        }).catch(function(){clearInterval(iv);toast('Investigation failed');
          document.getElementById('startBtn').disabled=false;});
    }
    </script>"""
    return render("New Investigation", "new_investigation", body, js)


def _signal_rows(signals):
    out = ""
    for s in signals:
        detail = ""
        d = s.get("details", {})
        if s["provider"] == "VirusTotal" and "detections" in d:
            detail = "%s detections / %s engines" % (d.get("detections"), d.get("engines"))
        elif s["provider"] == "HIBP":
            detail = "%s breach(es)" % d.get("breach_count", 0) if d.get("breached") else "No known breach"
        elif s["provider"] == "DNS":
            detail = ", ".join(list(d.get("records", {}).keys())) or (s.get("error") or "-")
        elif s["provider"] == "WHOIS":
            detail = "Age: %s days" % d.get("domain_age_days") if d.get("domain_age_days") is not None else (s.get("error") or "-")
        elif s["provider"] == "SSL":
            detail = "%s days left" % d.get("days_remaining") if d.get("days_remaining") is not None else (s.get("error") or "-")
        else:
            detail = s.get("error") or "-"
        sim = ' <span class="tag">SIM</span>' if d.get("simulated") else ""
        out += """<tr><td>{p}{sim}</td><td><span class="badge-v v-{st}">{st}</span></td>
          <td><span class="badge-v v-{v}">{v}</span></td><td class="muted">{det}</td></tr>""".format(
            p=s["provider"], sim=sim, st=s["status"], v=s["verdict"], det=detail)
    return out


@app.route("/investigation/<pid>")
@login_required
def view_investigation(pid):
    u = current_user()
    inv = Investigation.query.filter_by(public_id=pid).first_or_404()
    if inv.user_id != u.id and u.role != "admin":
        abort(403)
    data = inv.result()
    ml = data.get("ml", {})
    corr = data.get("correlation", {})

    breakdown_rows = ""
    for b in corr.get("breakdown", []):
        breakdown_rows += """<tr><td>{c}</td><td>{r}</td><td>{w}</td>
          <td><b>{p} / {m}</b></td></tr>""".format(
            c=b["component"].replace("_", " ").title(), r=b["raw_score"],
            w=b["normalized_weight"], p=b["weighted_points"], m=b["max_points"])

    factors = "".join("<li>%s</li>" % f for f in data.get("explanation", {}).get("risk_factors", []))
    recs = "".join("<li>%s</li>" % r for r in data.get("recommendations", []))
    avail = ", ".join(corr.get("available_signals", []) or ["-"])
    unavail = ", ".join(corr.get("unavailable_signals", []) or ["-"])

    ml_prob = ("%.1f%%" % ml["probability"]) if ml.get("probability") is not None else "n/a"
    ml_conf = ("%.1f%%" % ml["confidence"]) if ml.get("confidence") is not None else "n/a"
    feats = ml.get("features", {})
    feat_tags = "".join('<span class="tag">%s: %s</span>' % (k, v) for k, v in feats.items())

    renorm_note = ('<div class="flash" style="background:#1c2436;color:#8ea0be;border:1px solid #243049">'
                   'Weights were re-normalized because one or more providers were unavailable.</div>'
                   ) if corr.get("renormalized") else ""

    body = """
    <div class="grid2">
      <div class="panel gauge-wrap"><h2>Risk Verdict</h2>{gauge}
        <p class="muted" style="margin-top:14px">Confidence: <b>{conf}%</b></p></div>
      <div class="panel"><h2>Executive Summary</h2>
        <div class="kv">
          <div>Investigation ID</div><div>{pid}</div>
          <div>Indicator</div><div style="word-break:break-all">{ind}</div>
          <div>Type</div><div>{t}</div>
          <div>Risk Score</div><div><b>{score} / 100</b></div>
          <div>Verdict</div><div><span class="badge-v v-{v}">{v}</span></div>
          <div>Mode</div><div><span class="badge-v v-{mode_class}">{mode}</span></div>
          <div>Timestamp</div><div>{ts}</div>
        </div>
        <div style="margin-top:16px">
          <a class="btn" href="{report}">\u2B07 DOWNLOAD PDF REPORT</a></div>
      </div>
    </div>

    <div class="panel"><h2>Threat Intelligence & Signals</h2>
      <table><thead><tr><th>Provider</th><th>Status</th><th>Verdict</th><th>Details</th></tr></thead>
      <tbody>{sig_rows}</tbody></table>
      <p class="muted" style="margin-top:10px">A provider marked <b>UNAVAILABLE</b> or
      <b>NOT_CONFIGURED</b> is never treated as "safe".</p>
    </div>

    <div class="grid2">
      <div class="panel"><h2>ML Prediction</h2>
        <div class="kv">
          <div>Prediction</div><div><b>{ml_pred}</b></div>
          <div>Malicious Probability</div><div>{ml_prob}</div>
          <div>Confidence</div><div>{ml_conf}</div>
        </div>
        <div class="bar" style="margin-top:12px"><span style="width:{ml_bar}%"></span></div>
      </div>
      <div class="panel"><h2>Risk Score Breakdown</h2>
        {renorm}
        <table><thead><tr><th>Component</th><th>Raw</th><th>Norm. Wt</th><th>Points</th></tr></thead>
        <tbody>{bd}</tbody></table>
        <div style="margin-top:10px" class="kv">
          <div>Available</div><div>{avail}</div>
          <div>Unavailable</div><div>{unavail}</div>
        </div>
      </div>
    </div>

    <div class="grid2">
      <div class="panel"><h2>AI Explanation</h2>
        <p class="muted">Why this indicator received this score:</p>
        <ul>{factors}</ul></div>
      <div class="panel"><h2>Security Recommendations</h2><ul>{recs}</ul></div>
    </div>

    <div class="panel"><h2>Technical Details</h2>
      <div class="kv"><div>Hostname</div><div>{host}</div>
        <div>Indicator Type</div><div>{t}</div></div>
      <p class="muted" style="margin-top:14px">Extracted ML features:</p>
      <div>{feat_tags}</div>
    </div>
    <p class="muted" style="font-size:12px">{disclaimer}</p>
    """.format(
        gauge=_gauge_svg(inv.risk_score), conf=inv.confidence, pid=inv.public_id,
        ind=inv.indicator_value, t=inv.indicator_type, score=inv.risk_score, v=inv.verdict,
        mode=inv.mode, mode_class="SUSPICIOUS" if inv.mode == "DEMO" else "SAFE",
        ts=inv.created_at.strftime("%Y-%m-%d %H:%M UTC"),
        report=url_for("download_report", pid=inv.public_id),
        sig_rows=_signal_rows(data.get("signals", [])),
        ml_pred=ml.get("prediction", "n/a"), ml_prob=ml_prob, ml_conf=ml_conf,
        ml_bar=int(ml.get("probability") or 0),
        renorm=renorm_note, bd=breakdown_rows or '<tr><td colspan="4" class="muted">No components</td></tr>',
        avail=avail, unavail=unavail, factors=factors, recs=recs,
        host=data.get("hostname") or "-", feat_tags=feat_tags, disclaimer=DISCLAIMER,
    )
    return render("Investigation " + inv.public_id, "history", body)


# =============================================================================
# Investigation history (search / filter / sort / paginate)
# =============================================================================
@app.route("/history")
@login_required
def history():
    u = current_user()
    page = max(1, int(request.args.get("page", 1) or 1))
    per = 12
    search = (request.args.get("q") or "").strip()
    filt = (request.args.get("filter") or "all").lower()
    sort = request.args.get("sort", "recent")

    q = Investigation.query.filter_by(user_id=u.id)
    if search:
        q = q.filter(Investigation.indicator_value.ilike("%%%s%%" % search))
    fmap = {"safe": ["LOW"], "suspicious": ["MEDIUM", "MODERATE"],
            "malicious": ["HIGH", "CRITICAL"], "critical": ["CRITICAL"]}
    if filt in fmap:
        q = q.filter(Investigation.verdict.in_(fmap[filt]))
    if sort == "score":
        q = q.order_by(Investigation.risk_score.desc())
    else:
        q = q.order_by(Investigation.created_at.desc())

    total = q.count()
    pages = max(1, math.ceil(total / per))
    items = q.offset((page - 1) * per).limit(per).all()

    rows = ""
    for inv in items:
        rows += """<tr><td><a href="{u}">{ind}</a></td><td>{t}</td><td>{s}</td>
          <td><span class="badge-v v-{v}">{v}</span></td><td class="muted">{d}</td>
          <td><a href="{u}">View</a> &middot; <a href="{r}">PDF</a></td></tr>""".format(
            u=url_for("view_investigation", pid=inv.public_id),
            ind=(inv.indicator_value[:40] + ("..." if len(inv.indicator_value) > 40 else "")),
            t=inv.indicator_type, s=inv.risk_score, v=inv.verdict,
            d=inv.created_at.strftime("%Y-%m-%d %H:%M"),
            r=url_for("download_report", pid=inv.public_id))
    if not rows:
        rows = '<tr><td colspan="6" class="muted">No investigations found.</td></tr>'

    def link(p):
        return url_for("history", page=p, q=search, filter=filt, sort=sort)
    pager = ""
    if page > 1:
        pager += '<a class="btn ghost" href="%s">Prev</a> ' % link(page - 1)
    pager += '<span class="muted">Page %s of %s (%s total)</span>' % (page, pages, total)
    if page < pages:
        pager += ' <a class="btn ghost" href="%s">Next</a>' % link(page + 1)

    filters = ""
    for f in ["all", "safe", "suspicious", "malicious", "critical"]:
        cls = "btn" if f == filt else "btn ghost"
        filters += '<a class="%s" href="%s">%s</a> ' % (
            cls, url_for("history", filter=f, q=search, sort=sort), f.title())

    body = """
    <div class="panel">
      <form method="get" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap">
        <div style="flex:1;min-width:220px"><label>Search indicator</label>
          <input name="q" value="{q}" placeholder="Search..."></div>
        <div><label>Sort</label>
          <select name="sort">
            <option value="recent" {s1}>Most recent</option>
            <option value="score" {s2}>Highest risk</option></select></div>
        <button class="btn">Apply</button>
      </form>
      <div style="margin-top:14px">{filters}</div>
    </div>
    <div class="panel">
      <table><thead><tr><th>Indicator</th><th>Type</th><th>Score</th><th>Verdict</th>
        <th>Date</th><th>Actions</th></tr></thead><tbody>{rows}</tbody></table>
      <div style="margin-top:16px;display:flex;gap:10px;align-items:center">{pager}</div>
    </div>
    """.format(q=search, filters=filters, rows=rows, pager=pager,
               s1="selected" if sort == "recent" else "",
               s2="selected" if sort == "score" else "")
    return render("Investigation History", "history", body)


# =============================================================================
# Threat Intelligence status page
# =============================================================================
@app.route("/threat-intelligence")
@login_required
def threat_intel():
    status = provider_status_map()
    descriptions = {
        "VirusTotal": "URL / domain / IP / file-hash reputation across 70+ engines.",
        "PhishTank": "Community phishing URL database lookups.",
        "HIBP": "Email breach exposure checks (Have I Been Pwned).",
        "DNS": "A / AAAA / MX / NS / TXT / CNAME record analysis (dnspython).",
        "WHOIS": "Registrar, registration & expiry dates, domain age.",
        "SSL": "Certificate subject/issuer/validity and days remaining.",
    }
    cards = ""
    for name, desc in descriptions.items():
        configured = status.get(name, False)
        if name in ("DNS", "SSL", "WHOIS"):
            label = "Available" if configured else "Unavailable"
            v = "SAFE" if configured else "UNAVAILABLE"
        else:
            label = "Configured" if configured else "Not Configured"
            v = "SAFE" if configured else "NOT_CONFIGURED"
        cards += """<div class="card"><h3>{n}</h3>
          <span class="badge-v v-{v}">{label}</span>
          <p class="muted" style="margin-top:10px;font-size:13px">{d}</p></div>""".format(
            n=name, v=v, label=label, d=desc)
    body = """
    <div class="panel"><h2>Provider Availability</h2>
      <p class="muted">API keys are read from environment variables and are never exposed to
      the browser. Unconfigured providers stay usable in DEMO MODE with clearly labelled
      simulated data.</p></div>
    <div class="cards">{cards}</div>
    """.format(cards=cards)
    return render("Threat Intelligence", "threat_intel", body)


# =============================================================================
# Machine Learning Center
# =============================================================================
@app.route("/ml")
@login_required
def ml_center():
    status = "Trained" if (ML.model is not None) else "Not trained"
    m = ML.metrics or {}
    meta = ML.meta or {}
    cm = m.get("confusion_matrix")
    cm_html = ""
    if cm:
        cm_html = "<table><thead><tr><th></th>"
        classes = m.get("classes", CLASS_NAMES)
        for c in classes:
            cm_html += "<th>Pred %s</th>" % c
        cm_html += "</tr></thead><tbody>"
        for i, row in enumerate(cm):
            cm_html += "<tr><td><b>True %s</b></td>" % (classes[i] if i < len(classes) else i)
            for val in row:
                cm_html += "<td>%s</td>" % val
            cm_html += "</tr>"
        cm_html += "</tbody></table>"

    body = """
    <div class="cards">
      <div class="card"><h3>Model Status</h3><div class="big" style="font-size:22px">{status}</div></div>
      <div class="card"><h3>Training Samples</h3><div class="big">{samples}</div></div>
      <div class="card"><h3>Accuracy</h3><div class="big" style="color:#4ade80">{acc}</div></div>
      <div class="card"><h3>F1 Score</h3><div class="big" style="color:#22d3ee">{f1}</div></div>
    </div>
    <div style="height:18px"></div>
    <div class="grid2">
      <div class="panel"><h2>Model Metrics</h2>
        <div class="kv">
          <div>Model Type</div><div>{mtype}</div>
          <div>Precision</div><div>{prec}</div>
          <div>Recall</div><div>{rec}</div>
          <div>F1 Score</div><div>{f1}</div>
          <div>Last Trained</div><div>{trained}</div>
          <div>Dataset Source</div><div>{source}</div>
        </div>
        <div style="margin-top:16px">
          <button class="btn" id="trainBtn" onclick="trainModel()">\U0001F504 Train / Retrain Model</button>
        </div>
        <p class="muted" style="margin-top:10px;font-size:12px">Default training uses a clearly
        labelled DEMONSTRATION DATASET synthesised from URL characteristics. It is not real-world
        threat intelligence.</p>
      </div>
      <div class="panel"><h2>Confusion Matrix</h2>
        {cm}
      </div>
    </div>
    """.format(status=status, samples=meta.get("samples", "-"),
               acc=m.get("accuracy", "-"), f1=m.get("f1", "-"),
               mtype=meta.get("model_type", "RandomForestClassifier"),
               prec=m.get("precision", "-"), rec=m.get("recall", "-"),
               trained=meta.get("trained_at", "Never"), source=meta.get("source", "-"),
               cm=cm_html or '<p class="muted">Train the model to see a confusion matrix.</p>')

    js = """<script>
    function trainModel(){
      var b=document.getElementById('trainBtn');b.disabled=true;b.textContent='Training...';
      fetch('/api/train-model',{method:'POST',headers:{'X-CSRFToken':csrfToken()}})
        .then(r=>r.json()).then(function(d){
          if(d.error){toast(d.error);}else{toast('Model trained. Accuracy '+d.accuracy);
            setTimeout(function(){location.reload();},900);}
          b.disabled=false;b.textContent='\U0001F504 Train / Retrain Model';
        }).catch(function(){toast('Training failed');b.disabled=false;});
    }</script>"""
    return render("Machine Learning Center", "ml_center", body, js)


# =============================================================================
# Billing & subscription
# =============================================================================
@app.route("/billing")
@login_required
def billing():
    u = current_user()
    payments = Payment.query.filter_by(user_id=u.id).order_by(Payment.created_at.desc()).limit(20).all()
    prows = ""
    for p in payments:
        demo = '<span class="tag">DEMO</span>' if p.is_demo else ""
        prows += """<tr><td>{tx} {demo}</td><td>{plan}</td><td>{m}</td>
          <td>{amt} {cur}</td><td><span class="badge-v v-{sc}">{st}</span></td>
          <td class="muted">{d}</td></tr>""".format(
            tx=p.transaction_id, demo=demo, plan=(p.plan or "").title(), m=(p.method or "").title(),
            amt=int(p.amount), cur=p.currency, sc="SAFE" if p.status == "success" else "SUSPICIOUS",
            st=p.status, d=p.created_at.strftime("%Y-%m-%d"))
    if not prows:
        prows = '<tr><td colspan="6" class="muted">No payments yet.</td></tr>'

    plan_cards = ""
    for key, plan in PLANS.items():
        featured = "featured" if key == "pro" else ""
        current = key == u.plan
        btn = ('<span class="badge-v v-SAFE">Current Plan</span>' if current else
               '<div style="margin-top:12px;display:flex;gap:8px">'
               '<button class="btn ghost" onclick="pay(\'%s\',\'easypaisa\')">Easypaisa</button>'
               '<button class="btn" onclick="pay(\'%s\',\'jazzcash\')">JazzCash</button></div>'
               % (key, key))
        feats = "".join("<li>%s</li>" % f for f in plan["features"])
        plan_cards += """<div class="plan {f}"><h3>{name}</h3>
          <div class="price">PKR {price}<span class="muted" style="font-size:13px">/mo</span></div>
          <ul style="padding-left:18px;font-size:13px">{feats}</ul>{btn}</div>""".format(
            f=featured, name=plan["name"], price=plan["price"], feats=feats, btn=btn)

    body = """
    <div class="cards">
      <div class="card"><h3>Current Plan</h3><div class="big" style="font-size:22px">{plan}</div></div>
      <div class="card"><h3>Monthly Usage</h3><div class="big">{used}</div></div>
      <div class="card"><h3>Remaining Scans</h3><div class="big" style="color:#4ade80">{rem}</div></div>
      <div class="card"><h3>Plan Limit</h3><div class="big">{lim}</div></div>
    </div>
    <div style="height:18px"></div>
    <div class="panel"><h2>Plans</h2><div class="grid3">{plans}</div>
      <p class="muted" style="margin-top:14px;font-size:12px">Payments run in
      <b>DEMO PAYMENT MODE</b> unless real Easypaisa/JazzCash merchant credentials are configured.
      Demo transactions charge no real money and are clearly labelled.</p></div>
    <div class="panel"><h2>Payment History & Invoices</h2>
      <table><thead><tr><th>Transaction</th><th>Plan</th><th>Method</th><th>Amount</th>
        <th>Status</th><th>Date</th></tr></thead><tbody>{prows}</tbody></table></div>
    """.format(plan=PLANS[u.plan]["name"], used=u.scans_used, rem=u.remaining_scans(),
               lim=u.plan_limit(), plans=plan_cards, prows=prows)

    js = """<script>
    function pay(plan,method){
      fetch('/api/payment/create',{method:'POST',headers:{'Content-Type':'application/json',
        'X-CSRFToken':csrfToken()},body:JSON.stringify({plan:plan,method:method})})
        .then(r=>r.json()).then(function(d){
          if(d.success){toast(d.message+' ('+d.transaction_id+')');
            setTimeout(function(){location.reload();},1400);}
          else{toast(d.message||'Payment failed');}
        }).catch(function(){toast('Payment error');});
    }</script>"""
    return render("Billing & Subscription", "billing", body, js)


# =============================================================================
# Notifications
# =============================================================================
@app.route("/notifications")
@login_required
def notifications():
    u = current_user()
    items = Notification.query.filter_by(user_id=u.id).order_by(Notification.created_at.desc()).limit(50).all()
    rows = ""
    for n in items:
        vmap = {"critical": "CRITICAL", "warning": "MEDIUM", "success": "SAFE", "info": "NORMAL"}
        rows += """<tr><td><span class="badge-v v-{v}">{lvl}</span></td>
          <td><b>{t}</b><br><span class="muted">{b}</span></td>
          <td class="muted">{d}</td><td>{read}</td></tr>""".format(
            v=vmap.get(n.level, "NORMAL"), lvl=n.level.title(), t=n.title, b=n.body,
            d=n.created_at.strftime("%Y-%m-%d %H:%M"),
            read="Read" if n.is_read else '<span class="tag">New</span>')
    if not rows:
        rows = '<tr><td colspan="4" class="muted">No notifications.</td></tr>'
    body = """
    <div class="panel">
      <div style="display:flex;align-items:center"><h2 style="margin:0">Notifications</h2>
        <div class="spacer" style="flex:1"></div>
        <button class="btn ghost" onclick="markAll()">Mark all read</button></div>
      <table style="margin-top:14px"><thead><tr><th>Level</th><th>Message</th><th>Date</th><th></th></tr></thead>
      <tbody>{rows}</tbody></table>
    </div>""".format(rows=rows)
    js = """<script>
    function markAll(){fetch('/api/notifications/read-all',{method:'POST',
      headers:{'X-CSRFToken':csrfToken()}}).then(function(){location.reload();});}
    </script>"""
    return render("Notifications", "notifications", body, js)


# =============================================================================
# Settings
# =============================================================================
@app.route("/settings", methods=["GET", "POST"])
@login_required
def settings():
    u = current_user()
    if request.method == "POST":
        action = request.form.get("action")
        if action == "profile":
            u.name = (request.form.get("name") or u.name).strip()
            db.session.commit()
            flash("Profile updated.", "success")
        elif action == "password":
            cur = request.form.get("current") or ""
            new = request.form.get("new") or ""
            if not u.check_password(cur):
                flash("Current password is incorrect.", "error")
            elif len(new) < 6:
                flash("New password must be at least 6 characters.", "error")
            else:
                u.set_password(new)
                db.session.commit()
                audit("password_change", user_id=u.id)
                flash("Password changed.", "success")
        return redirect(url_for("settings"))

    status = provider_status_map()
    prov_rows = ""
    for name, ok in status.items():
        prov_rows += '<tr><td>%s</td><td><span class="badge-v v-%s">%s</span></td></tr>' % (
            name, "SAFE" if ok else "NOT_CONFIGURED",
            "Configured/Available" if ok else "Not Configured")

    recent_logins = AuditLog.query.filter_by(user_id=u.id, action="login").order_by(
        AuditLog.created_at.desc()).limit(5).all()
    login_rows = "".join(
        '<tr><td>%s</td><td class="muted">%s</td></tr>' % (
            l.ip_address or "-", l.created_at.strftime("%Y-%m-%d %H:%M"))
        for l in recent_logins) or '<tr><td colspan="2" class="muted">No logins recorded.</td></tr>'

    body = """
    <div class="grid2">
      <div class="panel"><h2>Account</h2>
        <form method="post"><input type="hidden" name="csrf_token" value="{token}">
          <input type="hidden" name="action" value="profile">
          <label>Name</label><input name="name" value="{name}">
          <label>Email</label><input value="{email}" disabled>
          <div style="height:12px"></div><button class="btn">Save Profile</button></form></div>
      <div class="panel"><h2>Change Password</h2>
        <form method="post"><input type="hidden" name="csrf_token" value="{token}">
          <input type="hidden" name="action" value="password">
          <label>Current Password</label><input type="password" name="current">
          <label>New Password</label><input type="password" name="new" minlength="6">
          <div style="height:12px"></div><button class="btn">Update Password</button></form></div>
    </div>
    <div class="grid2">
      <div class="panel"><h2>Subscription</h2>
        <div class="kv"><div>Current Plan</div><div>{plan}</div>
          <div>Usage</div><div>{used} / {lim}</div>
          <div>Remaining</div><div>{rem}</div></div></div>
      <div class="panel"><h2>Security / Login Activity</h2>
        <table><thead><tr><th>IP</th><th>Time</th></tr></thead><tbody>{logins}</tbody></table></div>
    </div>
    <div class="panel"><h2>API / Provider Status</h2>
      <table><thead><tr><th>Provider</th><th>Status</th></tr></thead><tbody>{provs}</tbody></table></div>
    """.format(token=_csrf_token(), name=u.name, email=u.email, plan=PLANS[u.plan]["name"],
               used=u.scans_used, lim=u.plan_limit(), rem=u.remaining_scans(),
               logins=login_rows, provs=prov_rows)
    return render("Settings", "settings", body)


def _csrf_token():
    try:
        if _HAS_CSRF:
            from flask_wtf.csrf import generate_csrf
            return generate_csrf()
    except Exception:
        pass
    return ""


# =============================================================================
# Admin panel
# =============================================================================
@app.route("/admin")
@login_required
@admin_required
def admin():
    users = User.query.order_by(User.created_at.desc()).all()
    inv_count = Investigation.query.count()
    pay_count = Payment.query.count()
    logs = AuditLog.query.order_by(AuditLog.created_at.desc()).limit(30).all()

    urows = ""
    for x in users:
        urows += """<tr><td>{n}</td><td>{e}</td><td>{r}</td><td>{p}</td>
          <td>{s}</td><td class="muted">{d}</td></tr>""".format(
            n=x.name, e=x.email, r=x.role, p=x.plan, s=x.scans_used,
            d=x.created_at.strftime("%Y-%m-%d"))

    lrows = ""
    for l in logs:
        lrows += """<tr><td>{a}</td><td class="muted">{u}</td><td class="muted">{i}</td>
          <td class="muted">{r}</td><td class="muted">{ip}</td><td class="muted">{d}</td></tr>""".format(
            a=l.action, u=l.user_id or "-", i=(l.indicator or "-")[:40],
            r=l.result or "-", ip=l.ip_address or "-",
            d=l.created_at.strftime("%Y-%m-%d %H:%M"))

    status = provider_status_map()
    prov_rows = ""
    for name, ok in status.items():
        prov_rows += '<tr><td>%s</td><td><span class="badge-v v-%s">%s</span></td><td class="muted">%s</td></tr>' % (
            name, "SAFE" if ok else "NOT_CONFIGURED",
            "Configured" if ok else "Not Configured", "********" if ok else "-")

    body = """
    <div class="cards">
      <div class="card"><h3>Total Users</h3><div class="big">{users}</div></div>
      <div class="card"><h3>Total Investigations</h3><div class="big">{inv}</div></div>
      <div class="card"><h3>Total Payments</h3><div class="big">{pay}</div></div>
      <div class="card"><h3>Audit Entries</h3><div class="big">{logs}</div></div>
    </div>
    <div style="height:18px"></div>
    <div class="panel"><h2>Users</h2>
      <table><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Plan</th>
        <th>Scans</th><th>Joined</th></tr></thead><tbody>{urows}</tbody></table></div>
    <div class="panel"><h2>API Configuration Status</h2>
      <p class="muted">Secret values are never displayed.</p>
      <table><thead><tr><th>Provider</th><th>Status</th><th>Secret</th></tr></thead>
        <tbody>{prov_rows}</tbody></table></div>
    <div class="panel"><h2>Audit Logs</h2>
      <table><thead><tr><th>Action</th><th>User</th><th>Indicator</th><th>Result</th>
        <th>IP</th><th>Time</th></tr></thead><tbody>{lrows}</tbody></table></div>
    """.format(users=len(users), inv=inv_count, pay=pay_count, logs=len(logs),
               urows=urows, prov_rows=prov_rows,
               lrows=lrows or '<tr><td colspan="6" class="muted">No logs.</td></tr>')
    return render("Admin Panel", "admin", body)


# =============================================================================
# PDF report download (owner or admin only)
# =============================================================================
@app.route("/report/<pid>")
@login_required
def download_report(pid):
    u = current_user()
    inv = Investigation.query.filter_by(public_id=pid).first_or_404()
    if inv.user_id != u.id and u.role != "admin":
        abort(403)
    if not _HAS_PDF:
        flash("PDF generation is unavailable (reportlab not installed).", "error")
        return redirect(url_for("view_investigation", pid=pid))
    try:
        buf = ReportGenerator().generate(inv)
        db.session.add(Report(investigation_id=inv.id, user_id=u.id))
        db.session.commit()
        notify(u.id, "Report generated", "Report for %s is ready." % pid, "info")
        audit("report_download", indicator=inv.indicator_value, user_id=u.id)
        return send_file(buf, mimetype="application/pdf", as_attachment=True,
                         download_name="%s_report.pdf" % pid)
    except Exception as exc:
        log.warning("PDF failed: %s", exc)
        flash("Could not generate PDF report.", "error")
        return redirect(url_for("view_investigation", pid=pid))


# =============================================================================
# REST API
# =============================================================================
@app.route("/api/detect")
@login_required
def api_detect():
    value = request.args.get("value", "")
    itype = detect_indicator_type(value)
    return jsonify({"type": itype, "hash_kind": hash_kind(value) if itype == "HASH" else None})


@app.route("/api/investigate", methods=["POST"])
@login_required
@rate_limit("60 per hour")
def api_investigate():
    u = current_user()
    if u.remaining_scans() <= 0:
        return jsonify({"error": "Monthly scan limit reached. Upgrade your plan."}), 402
    data = request.get_json(silent=True) or {}
    indicator = (data.get("indicator") or "").strip()
    ok, msg = validate_indicator(indicator)
    if not ok:
        return jsonify({"error": msg}), 400
    result = ORCH.investigate(indicator, u)
    if "error" in result:
        return jsonify({"error": result["error"]}), 400
    return jsonify({
        "investigation_id": result["investigation_id"],
        "risk_score": result["risk_score"],
        "verdict": result["verdict"],
        "confidence": result["confidence"],
    })


@app.route("/api/investigations")
@login_required
def api_investigations():
    u = current_user()
    items = Investigation.query.filter_by(user_id=u.id).order_by(
        Investigation.created_at.desc()).limit(100).all()
    return jsonify([{
        "id": i.public_id, "indicator": i.indicator_value, "type": i.indicator_type,
        "risk_score": i.risk_score, "verdict": i.verdict,
        "created_at": i.created_at.isoformat(),
    } for i in items])


@app.route("/api/investigation/<pid>")
@login_required
def api_investigation(pid):
    u = current_user()
    inv = Investigation.query.filter_by(public_id=pid).first()
    if not inv:
        return jsonify({"error": "not found"}), 404
    if inv.user_id != u.id and u.role != "admin":
        return jsonify({"error": "forbidden"}), 403
    return jsonify(inv.result())


@app.route("/api/report/<pid>")
@login_required
def api_report(pid):
    return download_report(pid)


@app.route("/api/train-model", methods=["POST"])
@login_required
@rate_limit("20 per hour")
def api_train_model():
    if not _HAS_ML:
        return jsonify({"error": "scikit-learn not available"}), 503
    try:
        rows = generate_sample_dataset()
        metrics = ML.train_from_rows(rows, source="DEMONSTRATION DATASET")
        audit("train_model", result="acc=%s" % metrics.get("accuracy"))
        return jsonify({"ok": True, **metrics})
    except Exception as exc:
        log.warning("train failed: %s", exc)
        return jsonify({"error": "Training failed: %s" % exc}), 500


@app.route("/api/ml-metrics")
@login_required
def api_ml_metrics():
    return jsonify({"metrics": ML.metrics, "meta": ML.meta,
                    "trained": ML.model is not None})


@app.route("/api/payment/create", methods=["POST"])
@login_required
@rate_limit("30 per hour")
def api_payment_create():
    u = current_user()
    data = request.get_json(silent=True) or {}
    plan = (data.get("plan") or "").lower()
    method = (data.get("method") or "").lower()
    if plan not in PLANS or plan == "free":
        return jsonify({"error": "Invalid plan"}), 400
    if method == "easypaisa":
        gw = EasypaisaPaymentGateway(app.config)
    elif method == "jazzcash":
        gw = JazzCashPaymentGateway(app.config)
    else:
        return jsonify({"error": "Invalid payment method"}), 400

    res = gw.create_payment(plan, u)
    pay = Payment(
        transaction_id=res.get("transaction_id") or ("TX-" + str(random.randint(100000, 999999))),
        user_id=u.id, plan=plan, method=method,
        amount=PLANS[plan]["price"], currency="PKR",
        status=res.get("status", "failure"), is_demo=res.get("is_demo", True))
    db.session.add(pay)

    if res.get("success"):
        u.plan = plan
        u.ensure_period()
        u.scans_used = 0
        sub = Subscription(user_id=u.id, plan=plan,
                           expiry_date=dt.datetime.utcnow() + dt.timedelta(days=30))
        db.session.add(sub)
        notify(u.id, "Payment successful",
               "Your %s plan is now active. %s" % (PLANS[plan]["name"], res.get("message", "")),
               "success")
        audit("payment", result="%s %s %s" % (method, plan, pay.transaction_id), user_id=u.id)
    db.session.commit()
    return jsonify(res)


@app.route("/api/payment/status")
@login_required
def api_payment_status():
    tx = request.args.get("transaction_id")
    p = Payment.query.filter_by(transaction_id=tx, user_id=session.get("uid")).first()
    if not p:
        return jsonify({"error": "not found"}), 404
    return jsonify({"transaction_id": p.transaction_id, "status": p.status,
                    "is_demo": p.is_demo, "amount": p.amount, "currency": p.currency})


@app.route("/api/payment/callback", methods=["POST"])
@csrf.exempt if _HAS_CSRF else (lambda f: f)
def api_payment_callback():
    """Gateway callback endpoint. In production the gateway posts here to confirm
    a transaction. Demo mode simply acknowledges."""
    data = request.get_json(silent=True) or request.form.to_dict()
    tx = data.get("transaction_id")
    status = data.get("status", "success")
    if tx:
        p = Payment.query.filter_by(transaction_id=tx).first()
        if p:
            p.status = status
            db.session.commit()
    return jsonify({"received": True})


@app.route("/api/notifications/read-all", methods=["POST"])
@login_required
def api_notifications_read_all():
    Notification.query.filter_by(user_id=session.get("uid"), is_read=False).update({"is_read": True})
    db.session.commit()
    return jsonify({"ok": True})


# =============================================================================
# Error handling
# =============================================================================
@app.errorhandler(403)
def err_403(e):
    if request.path.startswith("/api/"):
        return jsonify({"error": "forbidden"}), 403
    return render("Access Denied", "dashboard",
                  '<div class="panel"><h2>403 - Access Denied</h2>'
                  '<p class="muted">You do not have permission to view this resource.</p></div>'), 403


@app.errorhandler(404)
def err_404(e):
    if request.path.startswith("/api/"):
        return jsonify({"error": "not found"}), 404
    if not session.get("uid"):
        return redirect(url_for("login"))
    return render("Not Found", "dashboard",
                  '<div class="panel"><h2>404 - Not Found</h2>'
                  '<p class="muted">That page does not exist.</p></div>'), 404


@app.errorhandler(429)
def err_429(e):
    if request.path.startswith("/api/"):
        return jsonify({"error": "Too many requests. Please slow down."}), 429
    return render("Rate Limited", "dashboard",
                  '<div class="panel"><h2>429 - Too Many Requests</h2>'
                  '<p class="muted">Please slow down and try again shortly.</p></div>'), 429


@app.errorhandler(500)
def err_500(e):
    log.exception("internal error: %s", e)
    db.session.rollback()
    if request.path.startswith("/api/"):
        return jsonify({"error": "internal server error"}), 500
    return render("Error", "dashboard",
                  '<div class="panel"><h2>Something went wrong</h2>'
                  '<p class="muted">An internal error occurred. It has been logged.</p></div>'), 500


# =============================================================================
# Startup / bootstrap
# =============================================================================
def bootstrap():
    """Initialize DB, ML model, and (optionally) the admin account."""
    with app.app_context():
        db.create_all()

        # Load or train ML model
        if _HAS_ML:
            if not ML.load():
                try:
                    log.info("No trained model found. Generating demonstration model...")
                    ML.train_from_rows(generate_sample_dataset(), source="DEMONSTRATION DATASET")
                    log.info("Demonstration model trained (accuracy=%s).",
                             ML.metrics.get("accuracy"))
                except Exception as exc:
                    log.warning("Could not train demo model: %s", exc)
        else:
            log.warning("scikit-learn unavailable; ML features will report as unavailable.")

        # Create admin only when explicitly configured
        admin_email = app.config["ADMIN_EMAIL"]
        admin_pw = app.config["ADMIN_PASSWORD"]
        if admin_email and admin_pw:
            existing = User.query.filter_by(email=admin_email.lower()).first()
            if not existing:
                admin_user = User(name="Administrator", email=admin_email.lower(),
                                  role="admin", plan="business")
                admin_user.set_password(admin_pw)
                db.session.add(admin_user)
                db.session.commit()
                log.info("Admin account created for %s", admin_email)
        else:
            log.info("ADMIN_EMAIL / ADMIN_PASSWORD not set. No admin account created. "
                     "Set them in .env to bootstrap an administrator.")


if __name__ == "__main__":
    bootstrap()
    port = int(os.environ.get("PORT", "5000"))
    print("\n" + "=" * 52)
    print("  AI-Powered Threat Orchestrator")
    print("  Server running at:")
    print("  http://127.0.0.1:%d" % port)
    print("=" * 52 + "\n")
    app.run(host="127.0.0.1", port=port, debug=_bool_env("FLASK_DEBUG", False))
